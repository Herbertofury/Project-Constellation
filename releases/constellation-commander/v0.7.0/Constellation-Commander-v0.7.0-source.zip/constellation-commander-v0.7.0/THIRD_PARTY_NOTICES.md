# Third-party notices and research provenance

Constellation Commander is an independent implementation.

The design was informed by the public tool surface and documentation of Desktop Commander / Remote Desktop Commander and the open Model Context Protocol specification. Desktop Commander's hosted remote-service implementation is proprietary and was not copied.

Public references:
- https://github.com/desktop-commander/remote-desktop-commander
- https://github.com/wonderwhy-er/DesktopCommanderMCP
- https://modelcontextprotocol.io/

The upstream local DesktopCommanderMCP project is MIT licensed. This package currently contains original implementation code rather than copied upstream source; the reference is retained for provenance and future interoperability work.
