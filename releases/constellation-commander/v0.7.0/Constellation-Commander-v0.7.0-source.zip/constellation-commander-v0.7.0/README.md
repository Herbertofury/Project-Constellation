# Constellation Commander v0.7.0

Constellation Commander is a **local Windows work-agent companion built around your normal ChatGPT session**. It is no longer a hidden webview interceptor: v0.7 adds a visible desktop control plane around ChatGPT and keeps the local runtime observable, permissioned, recoverable, and useful even when the AI bridge needs attention.

## What you actually get

Open Commander and sign in to ChatGPT once. The app keeps that browser session in a dedicated persistent profile, then exposes a real local work runtime to the chat without an OpenAI API key or separately billed API path.

The visible Commander sidebar gives you:

- **Local tool mode:** Auto, Always, Off, or one-shot “Arm next message”.
- **Permission controls:** GUI/computer control, terminal/shell, Full PC or explicit workspace folders.
- **Emergency Lock:** immediately blocks local GUI automation until released.
- **Live status:** ChatGPT load state, Commander bridge readiness, available tool count, active tool, recent calls and failures.
- **Quick control:** observe the real desktop, see a fresh screenshot, list visible windows, and focus a window directly from Commander.
- **Real diagnostics:** a live ping plus Windows display/window enumeration—not a mock green light.
- **Recovery controls:** Home, Reload, ChatGPT DevTools, and direct access to Commander’s data directory.

## Local capabilities

The integrated runtime supports files/folders, exact block edits, recursive search, terminal sessions/processes, application launch/focus, screenshots, multi-monitor/window discovery, mouse, keyboard, hotkeys, drag/scroll, clipboard, Windows UI Automation, recent-call history and usage diagnostics.

Screenshots returned by local tools are attached back into the same ChatGPT conversation. Local calls are executed directly through Electron IPC; ChatGPT itself never receives Node or Electron privileges.

## Reliability model

Commander has two user-controlled ways to avoid “AI guessed wrong about whether this was local”:

- **Always** forces every outgoing prompt through Commander context.
- **Arm next message once** forces exactly the next message through Commander without changing your normal default.

The Windows acceptance gate must prove both halves of the product before a release is accepted:

1. the **visible shell** loads, its narrow IPC bridge works, its snapshot reports the real tool catalog, and its live health test passes;
2. the **ChatGPT integration** completes a real fixture prompt -> Commander tool call -> hidden tool result round trip.

The same proof is repeated after the one-click installer silently installs the packaged app.

## Packaging and runtime

- Electron **44.4.3**
- electron-builder **26.16.1**
- ASAR enabled for the application code
- only `native/**/*` is unpacked so the Windows computer-use PowerShell helper remains directly executable
- ChatGPT renderer: `nodeIntegration=false`, `contextIsolation=true`, Chromium sandbox enabled
- Commander shell renderer: same isolation/sandbox policy with a narrow `contextBridge` API

## Development

```text
npm run check
npm test
powershell -ExecutionPolicy Bypass -File scripts/electron-smoke.ps1
npm run build:win
```

The optional browser companion and relay remain available for non-Electron/fallback workflows, but the integrated Electron path is the primary Windows product.
