'use strict';

const { app, BrowserWindow, WebContentsView, ipcMain, Menu, shell, session, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const os = require('node:os');
const { pathToFileURL } = require('node:url');

const VERSION = '0.7.0';
const CHAT_URL = 'https://chatgpt.com/';
const CHAT_PARTITION = 'persist:constellation-chatgpt';
const SESSION_TTL_MS = 60 * 60 * 1000;
const SHELL_TOP = 48;
const SHELL_WIDTH = 380;
const TEST_MODE = process.env.CONSTELLATION_ELECTRON_SMOKE === '1';
const TEST_OUTPUT = process.env.CONSTELLATION_ELECTRON_SMOKE_OUTPUT || '';

let win;
let chatView;
let runtime;
let fallbackBridge;
let emergencyLock = false;
let shellCollapsed = false;
let shellSmokeState = { status: TEST_MODE ? 'pending' : 'not-required', detail: null };
let chatState = { phase: 'starting', message: 'Starting ChatGPT…', url: CHAT_URL, lastError: '', pageHookReady: false, loadedAt: '' };
const chatSessions = new Map();

function randomToken(bytes = 24) { return crypto.randomBytes(bytes).toString('base64url'); }
function nowIso() { return new Date().toISOString(); }
function smokeTrace(event, detail = {}) {
  if (!TEST_MODE || !TEST_OUTPUT) return;
  try { fs.appendFileSync(`${TEST_OUTPUT}.trace.log`, `${JSON.stringify({ at: nowIso(), event, detail })}\n`); } catch {}
}
function appRoot() { return path.resolve(__dirname, '..'); }
function importEsm(relativePath) { return import(pathToFileURL(path.join(appRoot(), relativePath)).href); }

function safeConfig() {
  if (!runtime?.config) return {};
  return {
    allowedRoots: Array.isArray(runtime.config.allowedRoots) ? [...runtime.config.allowedRoots] : [],
    enableShell: runtime.config.enableShell !== false,
    enableGuiAutomation: runtime.config.enableGuiAutomation !== false,
    localToolMode: ['auto', 'always', 'off'].includes(runtime.config.localToolMode) ? runtime.config.localToolMode : 'auto',
    browserBridgeEnabled: runtime.config.browserBridgeEnabled !== false,
    deviceName: runtime.config.deviceName || os.hostname()
  };
}

function emitShell(type, detail = {}) {
  if (!win || win.isDestroyed()) return;
  try { win.webContents.send('cc-shell:event', { type, at: nowIso(), detail }); } catch {}
}

function setChatState(patch) {
  chatState = { ...chatState, ...patch };
  emitShell('chat-state', chatState);
}

async function recentCalls(max = 30) {
  let text = '';
  try { text = await fs.promises.readFile(runtime.state.callsPath, 'utf8'); } catch {}
  if (!text.trim()) return [];
  const rows = [];
  for (const line of text.trim().split(/\r?\n/).slice(-Math.max(1, Math.min(100, max)))) {
    try { rows.push(JSON.parse(line)); } catch {}
  }
  return rows;
}

async function usageStats() {
  try { return JSON.parse(await fs.promises.readFile(runtime.state.statsPath, 'utf8')); }
  catch { return { totalCalls: 0, byTool: {}, errors: 0 }; }
}

async function shellSnapshot() {
  return {
    ok: true,
    product: 'Constellation Commander',
    version: VERSION,
    chat: { ...chatState },
    emergencyLock,
    shellCollapsed,
    singleInstanceOwner: app.hasSingleInstanceLock(),
    startWithWindows: app.isPackaged ? app.getLoginItemSettings().openAtLogin : false,
    config: safeConfig(),
    toolCount: toolManifest().length,
    recentCalls: await recentCalls(30),
    stats: await usageStats()
  };
}

async function persistConfigChange(key, value) {
  runtime.config[key] = value;
  await runtime.saveConfig(runtime.configPath, runtime.config);
  emitShell('config-changed', { key, value, config: safeConfig() });
  if (chatView && !chatView.webContents.isDestroyed()) {
    chatView.webContents.send('cc:config-changed', safeConfig());
  }
  return value;
}

async function createRuntime() {
  const [{ loadConfig, saveConfig }, { createRuntimeState }, { createToolHandler }, { toolDefinitions }] = await Promise.all([
    importEsm('src/config.mjs'), importEsm('src/state.mjs'), importEsm('src/tools.mjs'), importEsm('src/tool-definitions.mjs')
  ]);
  const loaded = await loadConfig();
  const state = createRuntimeState(loaded.dir);
  const callTool = createToolHandler({
    config: loaded.config,
    configPath: loaded.configPath,
    state,
    onShutdown: () => app.quit()
  });
  return { ...loaded, state, callTool, toolDefinitions, saveConfig };
}

function toolManifest() {
  return runtime.toolDefinitions()
    .filter(tool => !['list_devices', 'who_am_i', 'shutdown'].includes(tool.name))
    .map(tool => ({ name: tool.name, description: tool.description, inputSchema: tool.inputSchema || { type: 'object', properties: {} } }));
}

function getOrCreateSession(chatId, url) {
  const key = String(chatId || url || 'chat');
  const existing = chatSessions.get(key);
  if (existing && existing.expiresAt > Date.now() + 30000) return existing;
  const item = { nonce: randomToken(24), expiresAt: Date.now() + SESSION_TTL_MS, url: String(url || ''), chatId: key };
  chatSessions.set(key, item);
  return item;
}

function normalizeCall(input, sessionItem) {
  const raw = input && typeof input === 'object' ? input : {};
  const id = String(raw.id || `electron_${randomToken(12)}`);
  const tool = String(raw.tool || raw.name || '').trim();
  const args = raw.args && typeof raw.args === 'object' ? raw.args : raw.arguments && typeof raw.arguments === 'object' ? raw.arguments : raw.input && typeof raw.input === 'object' ? raw.input : {};
  const nonce = String(raw.nonce || sessionItem?.nonce || '');
  return { id, tool, args, nonce };
}

async function executeShellTool(tool, args = {}) {
  const id = `shell_${randomToken(10)}`;
  const started = Date.now();
  emitShell('tool-start', { id, tool, args: Object.keys(args || {}), source: 'shell' });
  try {
    const result = await runtime.callTool(tool, args);
    emitShell('tool-finish', { id, tool, durationMs: Date.now() - started, source: 'shell' });
    return result;
  } catch (error) {
    emitShell('tool-error', { id, tool, durationMs: Date.now() - started, error: String(error?.message || error), source: 'shell' });
    throw error;
  }
}

async function executeChatCall(chatId, rawCall) {
  const item = chatSessions.get(String(chatId || ''));
  if (!item || item.expiresAt <= Date.now()) throw new Error('Commander chat session expired; retry the request.');
  const call = normalizeCall(rawCall, item);
  if (!call.tool) throw new Error('Commander call did not specify a tool.');
  if (call.nonce !== item.nonce) throw new Error('Commander call nonce is stale.');
  const allowed = new Set(toolManifest().map(x => x.name));
  if (!allowed.has(call.tool)) throw new Error(`Commander tool is not available: ${call.tool}`);
  const started = Date.now();
  emitShell('tool-start', { id: call.id, tool: call.tool, args: Object.keys(call.args || {}) });
  try {
    const result = await runtime.callTool(call.tool, call.args);
    const attachments = Array.isArray(result?._attachments) ? result._attachments : [];
    let safeResult = result;
    if (safeResult && typeof safeResult === 'object') {
      safeResult = { ...safeResult };
      delete safeResult._attachments;
    }
    emitShell('tool-finish', { id: call.id, tool: call.tool, durationMs: Date.now() - started });
    return { ok: true, id: call.id, tool: call.tool, result: safeResult, _attachments: attachments };
  } catch (error) {
    emitShell('tool-error', { id: call.id, tool: call.tool, durationMs: Date.now() - started, error: String(error?.message || error) });
    throw error;
  }
}

async function setEmergencyLock(value) {
  emergencyLock = Boolean(value);
  runtime.config.emergencyLock = emergencyLock;
  await runtime.saveConfig(runtime.configPath, runtime.config);
  const lockPath = path.join(runtime.dir, 'EMERGENCY-LOCK');
  if (emergencyLock) fs.writeFileSync(lockPath, 'locked\n');
  else { try { fs.unlinkSync(lockPath); } catch {} }
  emitShell('emergency-lock', { enabled: emergencyLock });
  return emergencyLock;
}

function migrateLegacyInstall() {
  if (process.platform !== 'win32') return;
  const local = process.env.LOCALAPPDATA || '';
  if (!local) return;
  const legacyExe = path.join(local, 'ConstellationCommander', 'ConstellationCommander.exe');
  try {
    if (fs.existsSync(legacyExe) && path.resolve(legacyExe).toLowerCase() !== path.resolve(process.execPath).toLowerCase()) {
      const { spawn } = require('node:child_process');
      spawn('reg.exe', ['delete', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', '/v', 'ConstellationCommander', '/f'], { windowsHide: true, stdio: 'ignore' }).unref();
      const escaped = legacyExe.replaceAll("'", "''");
      const script = `Get-CimInstance Win32_Process -Filter \"Name='ConstellationCommander.exe'\" | Where-Object { $_.ExecutablePath -eq '${escaped}' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
      spawn('powershell.exe', ['-NoProfile','-NonInteractive','-Command', script], { windowsHide: true, stdio: 'ignore' }).unref();
    }
  } catch {}
}

function setStartWithWindows(enabled) {
  if (!app.isPackaged || TEST_MODE) return false;
  app.setLoginItemSettings({ openAtLogin: Boolean(enabled), path: process.execPath, args: [] });
  return app.getLoginItemSettings().openAtLogin;
}

async function startFallbackBridge() {
  if (runtime?.config?.browserBridgeEnabled === false) return;
  try {
    const { createBrowserBridge } = await importEsm('src/browser-bridge.mjs');
    fallbackBridge = await createBrowserBridge();
    await fallbackBridge.start();
  } catch (error) {
    console.warn('[Commander] fallback browser bridge unavailable:', error?.message || error);
  }
}

function chromeUserAgent() {
  const chrome = process.versions.chrome || '152.0.0.0';
  return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`;
}

function trustedNavigation(url) {
  if (TEST_MODE && String(url || '').startsWith('file://')) return true;
  try {
    const host = new URL(url).hostname.toLowerCase();
    return host === 'chatgpt.com' || host.endsWith('.chatgpt.com') || host === 'openai.com' || host.endsWith('.openai.com') || host.endsWith('.auth0.com') || host === 'accounts.google.com' || host === 'login.microsoftonline.com' || host.endsWith('.microsoftonline.com') || host === 'appleid.apple.com';
  } catch { return false; }
}

function injectPageHook() {
  if (!chatView || chatView.webContents.isDestroyed()) return;
  try {
    const source = fs.readFileSync(path.join(appRoot(), 'browser-companion', 'page-hook.js'), 'utf8');
    void chatView.webContents.executeJavaScript(source, true).catch(error => console.warn('[Commander] page hook injection failed:', error?.message || error));
  } catch (error) {
    console.warn('[Commander] page hook read failed:', error?.message || error);
  }
}

function createApplicationMenu() {
  const template = [
    { label: 'Commander', submenu: [
      { label: 'Full Control Test', accelerator: 'Ctrl+Shift+T', click: async () => {
        try {
          const result = await runtime.callTool('computer_observe', { max_width: 900, max_height: 700, window_limit: 20 });
          console.log('[Commander] Full Control Test PASS', JSON.stringify({ displays: result?.displays?.length, windows: result?.windows?.length }));
        } catch (error) { console.error('[Commander] Full Control Test FAIL', error); }
      }},
      { label: 'Emergency Lock', type: 'checkbox', checked: emergencyLock, click: item => { void setEmergencyLock(item.checked); } },
      { label: 'Start with Windows', type: 'checkbox', checked: app.isPackaged ? app.getLoginItemSettings().openAtLogin : false, click: item => { setStartWithWindows(item.checked); } },
      { type: 'separator' },
      { label: 'Open Commander Data Folder', click: () => shell.openPath(runtime.dir) },
      { label: 'Reload ChatGPT', accelerator: 'Ctrl+R', click: () => chatView?.webContents.reload() },
      { label: 'ChatGPT DevTools', accelerator: 'Ctrl+Shift+I', click: () => chatView?.webContents.openDevTools({ mode: 'detach' }) },
      { type: 'separator' },
      { role: 'quit' }
    ]},
    { label: 'Navigation', submenu: [
      { label: 'Back', accelerator: 'Alt+Left', click: () => chatView?.webContents.canGoBack() && chatView.webContents.goBack() },
      { label: 'Forward', accelerator: 'Alt+Right', click: () => chatView?.webContents.canGoForward() && chatView.webContents.goForward() },
      { label: 'Home', accelerator: 'Ctrl+Shift+H', click: () => chatView?.webContents.loadURL(CHAT_URL) }
    ]}
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function layoutChatView() {
  if (!win || !chatView) return;
  const [width, height] = win.getContentSize();
  const left = shellCollapsed ? 0 : SHELL_WIDTH;
  chatView.setBounds({ x: left, y: SHELL_TOP, width: Math.max(1, width - left), height: Math.max(1, height - SHELL_TOP) });
}

function createChatWindow() {
  const preload = path.join(__dirname, 'chat-preload.cjs');
  win = new BrowserWindow({
    width: 1500,
    height: 980,
    minWidth: 900,
    minHeight: 650,
    title: `Constellation Commander ${VERSION} — ChatGPT`,
    backgroundColor: '#0d0d0d',
    show: false,
    autoHideMenuBar: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      preload: path.join(__dirname, 'shell-preload.cjs')
    }
  });
  win.webContents.once('did-finish-load', () => {
    smokeTrace('shell-did-finish-load', { url: win.webContents.getURL() });
    if (!TEST_MODE) return;
    void win.webContents.executeJavaScript(`(async () => {
      const required = ['local-mode','root-list','emergency','activity','health','observe-desktop','window-list','direct-tool','direct-args','direct-run','direct-result'];
      const missing = required.filter(id => !document.getElementById(id));
      const api = window.commanderShell;
      if (!api || typeof api.snapshot !== 'function' || typeof api.runHealth !== 'function' || typeof api.observeDesktop !== 'function' || typeof api.listTools !== 'function' || typeof api.runTool !== 'function') {
        return { ok:false, reason:'shell-bridge-missing', missing, hasApi:Boolean(api) };
      }
      const snapshot = await api.snapshot();
      const tools = await api.listTools();
      const directPing = await api.runTool('ping', {});
      const health = await api.runHealth();
      return { ok: missing.length === 0 && snapshot?.ok === true && snapshot?.singleInstanceOwner === true && health?.ok === true && tools?.ok === true && tools?.tools?.length === snapshot?.toolCount && directPing?.ok === true && directPing?.result?.pong === true, missing, version:snapshot?.version, toolCount:snapshot?.toolCount, listedToolCount:tools?.tools?.length || 0, directPing:directPing?.result || null, localToolMode:snapshot?.config?.localToolMode, singleInstanceOwner:snapshot?.singleInstanceOwner === true, health };
    })()`, true).then(result => {
      shellSmokeState = { status: result?.ok ? 'passed' : 'failed', detail: result || null };
      smokeTrace('shell-runtime-proof', shellSmokeState);
      if (!result?.ok && TEST_OUTPUT) {
        fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok:false, event:'shell-runtime-failed', detail:result || null, at:nowIso() }, null, 2));
        setTimeout(() => app.quit(), 250);
      }
    }).catch(error => {
      shellSmokeState = { status:'failed', detail:{ error:String(error?.stack || error) } };
      smokeTrace('shell-runtime-proof-error', shellSmokeState.detail);
      if (TEST_OUTPUT) {
        fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok:false, event:'shell-runtime-failed', detail:shellSmokeState.detail, at:nowIso() }, null, 2));
        setTimeout(() => app.quit(), 250);
      }
    });
  });
  void win.loadFile(path.join(__dirname, 'shell.html'));

  // The BrowserWindow is only the native container. ChatGPT lives in a dedicated
  // WebContentsView so its session and preload are fully owned by Commander.
  chatView = new WebContentsView({
    webPreferences: {
      preload,
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      partition: CHAT_PARTITION,
      spellcheck: true
    }
  });
  win.contentView.addChildView(chatView);
  layoutChatView();
  win.on('resize', layoutChatView);
  win.on('closed', () => { win = null; chatView = null; });

  const wc = chatView.webContents;
  wc.setUserAgent(chromeUserAgent());
  wc.on('did-start-loading', () => setChatState({ phase: 'loading', message: 'Loading ChatGPT…', url: wc.getURL() || CHAT_URL, lastError: '', pageHookReady: false }));
  wc.on('dom-ready', injectPageHook);
  wc.on('did-fail-load', (_event, code, desc, url) => { console.warn('[Commander] ChatGPT load failed', code, desc, url); setChatState({ phase: 'error', message: 'ChatGPT failed to load', url, lastError: `${code}: ${desc}`, pageHookReady: false }); });
  wc.on('render-process-gone', (_event, details) => { console.warn('[Commander] ChatGPT renderer exited', details.reason); setChatState({ phase: 'error', message: 'ChatGPT renderer stopped', lastError: details.reason, pageHookReady: false }); });
  wc.setWindowOpenHandler(details => {
    if (!trustedNavigation(details.url)) {
      void shell.openExternal(details.url);
      return { action: 'deny' };
    }
    return {
      action: 'allow',
      overrideBrowserWindowOptions: {
        width: 920,
        height: 820,
        parent: win,
        modal: false,
        webPreferences: { partition: CHAT_PARTITION, nodeIntegration: false, contextIsolation: true, sandbox: true }
      }
    };
  });
  wc.on('will-navigate', (event, url) => {
    if (!trustedNavigation(url)) { event.preventDefault(); void shell.openExternal(url); }
  });

  const target = TEST_MODE ? `file://${path.join(__dirname, 'fixture-chat.html').replaceAll('\\', '/')}` : CHAT_URL;
  wc.once('did-finish-load', () => {
    smokeTrace('did-finish-load', { url: wc.getURL() });
    injectPageHook();
    setChatState({ phase: 'ready', message: 'ChatGPT ready', url: wc.getURL(), loadedAt: nowIso(), lastError: '' });
    if (!win.isVisible()) win.show();
    if (TEST_MODE) {
      setTimeout(() => {
        void wc.executeJavaScript(`(() => {
          const composer = document.getElementById('prompt-textarea') || document.querySelector('[contenteditable="true"][role="textbox"]');
          if (!composer) return { ok: false, reason: 'fixture-composer-missing', url: location.href, readyState: document.readyState };
          composer.focus();
          const rect = composer.getBoundingClientRect();
          return { ok: true, url: location.href, readyState: document.readyState, active: document.activeElement === composer, width: rect.width, height: rect.height, text: composer.innerText || composer.textContent || '' };
        })()`, true).then(result => {
          smokeTrace('fixture-focus-result', result || null);
          if (!result?.ok) {
            if (TEST_OUTPUT) fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: false, event: 'smoke-start-failed', detail: result || null, at: nowIso() }, null, 2));
            setTimeout(() => app.quit(), 250);
            return;
          }
          wc.sendInputEvent({ type: 'keyDown', keyCode: 'Enter' });
          wc.sendInputEvent({ type: 'keyUp', keyCode: 'Enter' });
          smokeTrace('native-enter-sent', { url: wc.getURL() });
        }).catch(error => {
          smokeTrace('fixture-focus-error', { error: String(error?.stack || error) });
          if (TEST_OUTPUT) {
            fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: false, event: 'smoke-start-failed', detail: { error: String(error?.stack || error) }, at: nowIso() }, null, 2));
            setTimeout(() => app.quit(), 250);
          }
        });
      }, 700);
    }
  });
  void wc.loadURL(target);
  win.once('ready-to-show', () => { if (!win.isVisible()) win.show(); });
}

function installIpc() {
  ipcMain.handle('cc:bootstrap', async (event, payload = {}) => {
    if (event.sender !== chatView?.webContents) throw new Error('Untrusted Commander bootstrap caller.');
    smokeTrace('ipc-bootstrap', { chatId: String(payload.chatId || ''), url: String(payload.url || '') });
    const item = getOrCreateSession(payload.chatId, payload.url);
    return {
      ok: true,
      product: 'Constellation Commander',
      version: VERSION,
      source: 'electron-integrated-workspace',
      nonce: item.nonce,
      expiresAt: new Date(item.expiresAt).toISOString(),
      tools: toolManifest(),
      contract: 'For local-PC work, use Constellation Commander directly. Emit exactly one [PC_BUDDY_CALL] JSON wrapper as the whole assistant response using this nonce and one available tool. After its hidden tool-result turn, continue the task and call the next tool when needed. Preferred shape: {"id":"fresh-id","nonce":"...","tool":"tool_name","args":{...}}. Do not tell the user to run local commands manually when a listed Commander tool can perform the action.'
    };
  });

  ipcMain.handle('cc:call', async (event, payload = {}) => {
    if (event.sender !== chatView?.webContents) throw new Error('Untrusted Commander tool caller.');
    smokeTrace('ipc-call', { chatId: String(payload.chatId || ''), tool: String(payload.call?.tool || payload.call?.name || '') });
    try {
      const result = await executeChatCall(payload.chatId, payload.call);
      smokeTrace('ipc-call-result', { ok: result?.ok !== false, tool: String(result?.tool || '') });
      return result;
    } catch (error) {
      smokeTrace('ipc-call-error', { error: String(error?.message || error) });
      return { ok: false, error: String(error?.message || error) };
    }
  });

  ipcMain.handle('cc:status', async event => {
    if (event.sender !== chatView?.webContents) throw new Error('Untrusted status caller.');
    return { ok: true, product: 'Constellation Commander', version: VERSION, mode: 'integrated-electron-chatgpt', emergencyLock, computerUseSupported: process.platform === 'win32', guiAutomationEnabled: runtime.config.enableGuiAutomation !== false, shellEnabled: runtime.config.enableShell !== false, localToolMode: runtime.config.localToolMode || 'auto', allowedRoots: runtime.config.allowedRoots || [], quotaEnforced: false };
  });

  ipcMain.handle('cc:diagnostic', async (_event, payload = {}) => {
    smokeTrace(`renderer:${String(payload.event || 'diagnostic')}`, payload.detail || {});
    emitShell('chat-diagnostic', { event: String(payload.event || 'diagnostic'), detail: payload.detail || {} });
    if (payload.event === 'page-hook-ready') setChatState({ pageHookReady: true, phase: 'ready', message: 'ChatGPT + Commander ready' });
    if (payload.event === 'arm-failed') setChatState({ phase: 'error', message: 'Commander arm failed', lastError: String(payload.detail?.error || 'Unknown arm failure') });
    if (TEST_MODE && TEST_OUTPUT) {
      if (payload.event === 'tool-result-sent') {
        if (shellSmokeState.status !== 'passed') {
          fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: false, event: 'shell-runtime-not-proven', detail: shellSmokeState, at: nowIso() }, null, 2));
        } else {
          fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: true, event: payload.event, detail: { ...(payload.detail || {}), shellRuntime: shellSmokeState.detail }, at: nowIso() }, null, 2));
        }
        setTimeout(() => app.quit(), 250);
      } else if (['arm-failed', 'tool-failed', 'smoke-start-failed'].includes(payload.event)) {
        fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: false, event: payload.event, detail: payload.detail || null, at: nowIso() }, null, 2));
        setTimeout(() => app.quit(), 250);
      }
    }
    return { ok: true };
  });
}

function installShellIpc() {
  const trusted = event => event.sender === win?.webContents;
  const requireTrusted = event => { if (!trusted(event)) throw new Error('Untrusted Commander shell caller.'); };

  ipcMain.handle('cc-shell:snapshot', async event => { requireTrusted(event); return shellSnapshot(); });
  ipcMain.handle('cc-shell:set-sidebar-collapsed', (event, payload = {}) => {
    requireTrusted(event);
    shellCollapsed = Boolean(payload.collapsed);
    layoutChatView();
    emitShell('sidebar-collapsed', { collapsed: shellCollapsed });
    return { ok: true, collapsed: shellCollapsed };
  });
  ipcMain.handle('cc-shell:arm-next', event => { requireTrusted(event); chatView?.webContents.send('cc:arm-next'); emitShell('arm-next', { armed: true }); return { ok: true }; });
  ipcMain.handle('cc-shell:set-local-mode', async (event, payload = {}) => {
    requireTrusted(event);
    const mode = String(payload.mode || 'auto');
    if (!['auto', 'always', 'off'].includes(mode)) throw new Error('Invalid local tool mode.');
    await persistConfigChange('localToolMode', mode);
    return { ok: true, mode };
  });
  ipcMain.handle('cc-shell:set-emergency-lock', async (event, payload = {}) => {
    requireTrusted(event);
    return { ok: true, enabled: await setEmergencyLock(Boolean(payload.enabled)) };
  });
  ipcMain.handle('cc-shell:set-option', async (event, payload = {}) => {
    requireTrusted(event);
    const key = String(payload.key || '');
    if (!['enableGuiAutomation', 'enableShell'].includes(key)) throw new Error(`Unsupported shell option: ${key}`);
    await persistConfigChange(key, Boolean(payload.value));
    return { ok: true, key, value: Boolean(payload.value) };
  });
  ipcMain.handle('cc-shell:set-full-access', async (event, payload = {}) => {
    requireTrusted(event);
    const enabled = Boolean(payload.enabled);
    const roots = enabled ? ['*'] : [os.homedir()];
    await persistConfigChange('allowedRoots', roots);
    return { ok: true, allowedRoots: roots };
  });
  ipcMain.handle('cc-shell:add-root', async event => {
    requireTrusted(event);
    const picked = await dialog.showOpenDialog(win, { title: 'Add Commander workspace folder', properties: ['openDirectory', 'createDirectory'] });
    if (picked.canceled || !picked.filePaths?.[0]) return { ok: true, canceled: true };
    const root = path.resolve(picked.filePaths[0]);
    const current = Array.isArray(runtime.config.allowedRoots) && !runtime.config.allowedRoots.includes('*') ? runtime.config.allowedRoots : [];
    const roots = [...new Set([...current, root])];
    await persistConfigChange('allowedRoots', roots);
    return { ok: true, root, allowedRoots: roots };
  });
  ipcMain.handle('cc-shell:remove-root', async (event, payload = {}) => {
    requireTrusted(event);
    const target = path.resolve(String(payload.root || ''));
    const roots = (Array.isArray(runtime.config.allowedRoots) ? runtime.config.allowedRoots : []).filter(root => root !== '*' && path.resolve(root) !== target);
    const next = roots.length ? roots : [os.homedir()];
    await persistConfigChange('allowedRoots', next);
    return { ok: true, allowedRoots: next };
  });
  ipcMain.handle('cc-shell:list-tools', async event => {
    requireTrusted(event);
    return { ok: true, tools: toolManifest() };
  });
  ipcMain.handle('cc-shell:run-tool', async (event, payload = {}) => {
    requireTrusted(event);
    const name = String(payload.name || '').trim();
    const definition = toolManifest().find(tool => tool.name === name);
    if (!definition) throw new Error(`Commander tool is not available: ${name || '(empty)'}`);
    const args = payload.args && typeof payload.args === 'object' && !Array.isArray(payload.args) ? payload.args : {};
    const result = await executeShellTool(name, args);
    const attachments = Array.isArray(result?._attachments) ? result._attachments : [];
    const image = attachments.find(item => item?.base64 && item?.mimeType?.startsWith('image/'));
    const safe = result && typeof result === 'object' ? { ...result } : result;
    if (safe && typeof safe === 'object') delete safe._attachments;
    return {
      ok: true,
      tool: name,
      result: safe,
      attachmentCount: attachments.length,
      imageDataUrl: image ? `data:${image.mimeType};base64,${image.base64}` : ''
    };
  });
  ipcMain.handle('cc-shell:run-health', async event => {
    requireTrusted(event);
    const started = Date.now();
    try {
      const ping = await executeShellTool('ping', {});
      let displayCount = 0;
      let windowCount = 0;
      if (process.platform === 'win32' && runtime.config.enableGuiAutomation !== false && !emergencyLock) {
        const displays = await executeShellTool('computer_displays', {});
        const windows = await executeShellTool('computer_windows', { limit: 12 });
        displayCount = displays?.displays?.length || 0;
        windowCount = windows?.windows?.length || 0;
      }
      const result = { ok: true, deviceName: ping?.deviceName || runtime.config.deviceName, displayCount, windowCount, durationMs: Date.now() - started };
      emitShell('health-result', result);
      return result;
    } catch (error) {
      const result = { ok: false, error: String(error?.message || error), durationMs: Date.now() - started };
      emitShell('health-result', result);
      return result;
    }
  });
  ipcMain.handle('cc-shell:observe-desktop', async event => {
    requireTrusted(event);
    const observed = await executeShellTool('computer_observe', { max_width: 1100, max_height: 760, window_limit: 30 });
    const attachments = Array.isArray(observed?._attachments) ? observed._attachments : [];
    const shot = attachments.find(item => item?.base64 && item?.mimeType);
    const safe = observed && typeof observed === 'object' ? { ...observed } : {};
    delete safe._attachments;
    return { ok: true, ...safe, imageDataUrl: shot ? `data:${shot.mimeType};base64,${shot.base64}` : '' };
  });
  ipcMain.handle('cc-shell:list-windows', async event => {
    requireTrusted(event);
    const result = await executeShellTool('computer_windows', { limit: 40 });
    return { ok: true, windows: result?.windows || [] };
  });
  ipcMain.handle('cc-shell:focus-window', async (event, payload = {}) => {
    requireTrusted(event);
    const args = {};
    if (payload.handle != null && payload.handle !== '') args.handle = payload.handle;
    else if (payload.pid != null) args.pid = Number(payload.pid);
    else if (payload.title) args.title = String(payload.title);
    else throw new Error('Window handle, pid, or title is required.');
    const result = await executeShellTool('computer_focus_window', args);
    return { ok: true, result };
  });

  ipcMain.handle('cc-shell:reload-chat', event => { requireTrusted(event); chatView?.webContents.reload(); return { ok: true }; });
  ipcMain.handle('cc-shell:go-home', event => { requireTrusted(event); void chatView?.webContents.loadURL(CHAT_URL); return { ok: true }; });
  ipcMain.handle('cc-shell:open-data-folder', event => { requireTrusted(event); void shell.openPath(runtime.dir); return { ok: true }; });
  ipcMain.handle('cc-shell:open-devtools', event => { requireTrusted(event); chatView?.webContents.openDevTools({ mode: 'detach' }); return { ok: true }; });
  ipcMain.handle('cc-shell:set-start-with-windows', (event, payload = {}) => { requireTrusted(event); return { ok: true, enabled: setStartWithWindows(Boolean(payload.enabled)) }; });
}

async function configureSession() {
  const ses = session.fromPartition(CHAT_PARTITION, { cache: true });
  ses.setPermissionRequestHandler((webContents, permission, callback) => {
    const url = webContents.getURL();
    const trusted = trustedNavigation(url);
    const allowed = trusted && ['notifications', 'clipboard-sanitized-write', 'media', 'fullscreen'].includes(permission);
    callback(Boolean(allowed));
  });
  ses.setPermissionCheckHandler((_webContents, permission, requestingOrigin) => trustedNavigation(requestingOrigin) && ['notifications', 'clipboard-sanitized-write', 'media', 'fullscreen'].includes(permission));
}

app.commandLine.appendSwitch('disable-features', 'HardwareMediaKeyHandling');
app.setAppUserModelId('com.constellation.commander');

const singleInstanceOwner = app.requestSingleInstanceLock();
if (!singleInstanceOwner) app.quit();

app.on('second-instance', () => {
  if (!singleInstanceOwner || !win || win.isDestroyed()) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
});

app.whenReady().then(async () => {
  if (!singleInstanceOwner) return;

  runtime = await createRuntime();
  migrateLegacyInstall();
  emergencyLock = Boolean(runtime.config.emergencyLock) || fs.existsSync(path.join(runtime.dir, 'EMERGENCY-LOCK'));
  await configureSession();
  installIpc();
  installShellIpc();
  createApplicationMenu();
  createChatWindow();
  void startFallbackBridge();
}).catch(error => {
  console.error('[Commander] fatal startup error', error);
  if (TEST_OUTPUT) try { fs.writeFileSync(TEST_OUTPUT, JSON.stringify({ ok: false, error: String(error?.stack || error) }, null, 2)); } catch {}
  app.quit();
});

app.on('window-all-closed', () => app.quit());
app.on('before-quit', async () => { try { await fallbackBridge?.stop?.(); } catch {} });
