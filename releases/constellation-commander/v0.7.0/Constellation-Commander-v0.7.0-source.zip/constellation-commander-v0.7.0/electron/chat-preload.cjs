'use strict';

const { ipcRenderer } = require('electron');

(() => {
  const VERSION = '0.7.0';
  const CONTEXT_OPEN = '[PROJECT CONSTELLATION LOCAL CONTEXT]';
  const CONTEXT_CLOSE = '[/PROJECT CONSTELLATION LOCAL CONTEXT]';
  const RESULT_OPEN = '[PC BUDDY TOOL RESULT]';
  const RESULT_CLOSE = '[/PC BUDDY TOOL RESULT]';
  const PAGE_SOURCE = 'constellation-commander-page-hook';
  const CONTENT_SOURCE = 'constellation-commander-content';
  const CALL_OPEN = '[PC_BUDDY_CALL]';
  const CALL_CLOSE = '[/PC_BUDDY_CALL]';
  const handledCalls = new Set();
  const pageWaiters = new Map();
  let pageHookReady = false;
  let session = null;
  let sessionChatId = '';
  let plumbingSend = false;
  let arming = false;
  let route = location.href;
  let localToolMode = 'auto';
  let forceNextPrompt = false;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const diagnostic = (event, detail = {}) => ipcRenderer.invoke('cc:diagnostic', { event, detail }).catch(() => null);
  ipcRenderer.on('cc:config-changed', (_event, config = {}) => { if (['auto','always','off'].includes(config.localToolMode)) localToolMode = config.localToolMode; });
  ipcRenderer.on('cc:arm-next', () => { forceNextPrompt = true; toast('Commander armed for the next message.'); void diagnostic('force-next-armed', { chatId: chatId() }); });
  void diagnostic('preload-loaded', { url: location.href, readyState: document.readyState });

  function toast(message, kind = 'info', sticky = false) {
    const id = 'constellation-commander-electron-toast';
    let node = document.getElementById(id);
    if (!node) {
      node = document.createElement('div');
      node.id = id;
      Object.assign(node.style, {
        position: 'fixed', right: '18px', bottom: '18px', zIndex: '2147483647', maxWidth: '440px',
        padding: '10px 13px', borderRadius: '10px', font: '13px/1.35 system-ui,sans-serif', color: '#fff',
        boxShadow: '0 8px 28px rgba(0,0,0,.35)', transition: 'opacity .15s ease', pointerEvents: 'none'
      });
      document.documentElement.appendChild(node);
    }
    node.textContent = message;
    node.style.background = kind === 'error' ? '#991b1b' : kind === 'warn' ? '#a16207' : '#166534';
    node.style.opacity = '1';
    clearTimeout(toast._timer);
    if (!sticky) toast._timer = setTimeout(() => { if (node) node.style.opacity = '0'; }, 2500);
  }

  function chatId() {
    const match = location.pathname.match(/\/c\/([^/?#]+)/i);
    return match?.[1] || `route:${location.pathname}${location.search}`;
  }

  function composer() {
    const selectors = [
      '#prompt-textarea.ProseMirror[contenteditable="true"]', '#prompt-textarea[contenteditable="true"]',
      'div.ProseMirror[contenteditable="true"][role="textbox"]', '[contenteditable="true"][role="textbox"]',
      'textarea[name="prompt-textarea"]', 'textarea[placeholder]'
    ];
    for (const selector of selectors) {
      for (const node of document.querySelectorAll(selector)) {
        if (!(node instanceof HTMLElement) || node.getAttribute('aria-disabled') === 'true') continue;
        const rect = node.getBoundingClientRect();
        const style = getComputedStyle(node);
        if (style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 20 && rect.height > 10) return node;
      }
    }
    return null;
  }

  function getComposerText(node) {
    if (node instanceof HTMLTextAreaElement || node instanceof HTMLInputElement) return node.value || '';
    return node?.innerText || node?.textContent || '';
  }

  function composerContains(node, value) {
    const normalize = text => String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    const actual = normalize(getComposerText(node));
    const expected = normalize(value);
    return expected ? actual.includes(expected.slice(0, Math.min(48, expected.length))) : !actual;
  }

  function selectEditableContents(node) {
    const selection = window.getSelection?.();
    if (!selection) return false;
    const range = document.createRange();
    range.selectNodeContents(node);
    selection.removeAllRanges();
    selection.addRange(range);
    return true;
  }

  function setComposerText(node, text) {
    if (!node) return false;
    const value = String(text ?? '');
    node.focus();
    if (node instanceof HTMLTextAreaElement || node instanceof HTMLInputElement) {
      const proto = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(node, value); else node.value = value;
      node.dispatchEvent(new Event('input', { bubbles: true }));
      node.dispatchEvent(new Event('change', { bubbles: true }));
      return composerContains(node, value);
    }
    let inserted = false;
    try { selectEditableContents(node); inserted = Boolean(document.execCommand?.('insertText', false, value)); } catch {}
    if (!inserted || !composerContains(node, value)) {
      try {
        selectEditableContents(node);
        const transfer = new DataTransfer(); transfer.setData('text/plain', value);
        node.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, composed: true, clipboardData: transfer }));
      } catch {}
    }
    if (!composerContains(node, value)) {
      const fragment = document.createDocumentFragment();
      for (const line of value.split('\n')) { const p = document.createElement('p'); if (line) p.textContent = line; else p.appendChild(document.createElement('br')); fragment.appendChild(p); }
      node.replaceChildren(fragment);
      node.dispatchEvent(new Event('input', { bubbles: true }));
    }
    node.dispatchEvent(new Event('change', { bubbles: true }));
    return composerContains(node, value);
  }

  function sendButton(node) {
    const scope = node?.closest('form') || node?.parentElement?.parentElement || document;
    const selectors = '#composer-submit-button,[data-testid="send-button"],button[aria-label*="send" i],button[data-testid*="send" i],button[type="submit"]';
    return [...(scope.querySelectorAll?.(selectors) || [])].find(button => !button.disabled && !/stop|cancel/i.test(`${button.getAttribute('aria-label') || ''} ${button.textContent || ''}`)) || null;
  }

  function recentConversationMentionsCommander() {
    const turns = [...document.querySelectorAll('[data-message-author-role="assistant"],[data-message-author-role="user"],article[data-turn]')].slice(-10);
    return turns.some(node => /Constellation Commander|computer use|take control|local companion/i.test(node.textContent || ''));
  }

  function isLocalIntent(text) {
    const value = String(text || '').trim();
    if (!value || value.includes(CONTEXT_OPEN) || value.includes(RESULT_OPEN)) return false;
    if (forceNextPrompt) return true;
    if (localToolMode === 'off') return false;
    if (localToolMode === 'always') return true;
    if (/\b(take|gain|give|have)\s+(?:full\s+)?control\b|\bcontrol\s+(?:my|this|the)?\s*(?:computer|pc|desktop|laptop|machine|workstation|screen)?\b/i.test(value)) return true;
    if (/\b(full\s+computer\s+use|computer[- ]use|use\s+my\s+(?:computer|pc|desktop|screen)|drive\s+my\s+(?:mouse|keyboard)|move\s+my\s+mouse|see\s+my\s+screen|remote\s+control)\b/i.test(value)) return true;
    if (/\b(local|locally|filesystem|file system|powershell|cmd|terminal|process|folder|directory|screen|screenshot|mouse|keyboard|clipboard|window|desktop|computer use)\b/i.test(value)) return true;
    if (/\b(open|read|write|edit|rename|move|copy|delete|trash|create|run|launch|kill|search|find|click|drag|scroll|type|press|focus|maximize|minimize|close|inspect|capture)\b.{0,70}\b(file|folder|directory|process|program|app|script|command|screen|desktop|window|button|menu|mouse|keyboard)\b/i.test(value)) return true;
    if (/(?:^|\s)[A-Za-z]:\\[^\s]+/.test(value) || /(?:^|\s)\\\\[^\s]+/.test(value)) return true;
    return /^(try again|test it|test now|do it|go ahead|continue|take over|use it|again|now)[.! ]*$/i.test(value) && recentConversationMentionsCommander();
  }

  async function ensureSession(force = false) {
    const id = chatId();
    if (!force && session && sessionChatId === id && Date.parse(session.expiresAt || '') > Date.now() + 30000) return session;
    const response = await ipcRenderer.invoke('cc:bootstrap', { chatId: id, url: location.href });
    if (!response?.ok) throw new Error(response?.error || 'Integrated Commander runtime is offline.');
    session = response; sessionChatId = id; return session;
  }

  function contextText(s) {
    return `${CONTEXT_OPEN}\n${JSON.stringify({ version: 3, product: 'Constellation Commander', source: 'electron-integrated-workspace', companionVersion: VERSION, nonce: s.nonce, expiresAt: s.expiresAt, tools: s.tools || [], contract: s.contract })}\n${CONTEXT_CLOSE}`;
  }

  function attachmentFile(attachment) {
    if (!attachment?.base64 || !attachment?.mimeType) return null;
    const raw = atob(attachment.base64); const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return new File([bytes], attachment.name || 'computer-screenshot.jpg', { type: attachment.mimeType });
  }

  async function attachFiles(attachments) {
    const files = (attachments || []).map(attachmentFile).filter(Boolean);
    if (!files.length) return;
    let input = document.querySelector('input#upload-files') || document.querySelector('input#upload-photos') || [...document.querySelectorAll('input[type="file"]')].find(el => !el.disabled);
    if (!input) {
      const addButton = document.querySelector('[data-testid="composer-plus-btn"]') || [...document.querySelectorAll('button')].find(button => /attach|upload|add files|photos/i.test(`${button.getAttribute('aria-label') || ''} ${button.textContent || ''}`));
      addButton?.click();
      for (let i = 0; i < 30 && !input; i++) { await sleep(100); input = document.querySelector('input#upload-files') || document.querySelector('input#upload-photos') || [...document.querySelectorAll('input[type="file"]')].find(el => !el.disabled); }
    }
    if (!input) throw new Error('ChatGPT file input is unavailable for the Commander screenshot.');
    const transfer = new DataTransfer(); for (const file of files) transfer.items.add(file);
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'files')?.set;
    if (setter) setter.call(input, transfer.files); else input.files = transfer.files;
    input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(500);
  }

  async function waitPageHookReady(timeout = 2500) {
    if (pageHookReady) return true;
    const until = Date.now() + timeout;
    while (!pageHookReady && Date.now() < until) await sleep(40);
    return pageHookReady;
  }

  function armPageHook(original, context) {
    const id = crypto.randomUUID?.() || `cc-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const promise = new Promise(resolve => {
      const timer = setTimeout(() => { pageWaiters.delete(id); resolve({ ok: false, timeout: true }); }, 5000);
      pageWaiters.set(id, { resolve, timer });
    });
    window.postMessage({ source: CONTENT_SOURCE, type: 'CC_ARM_CONTEXT_V2', id, original, context }, '*');
    return { id, promise };
  }

  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.source !== PAGE_SOURCE) return;
    const data = event.data;
    if (data.type === 'CC_PAGE_HOOK_READY_V2') { pageHookReady = true; void diagnostic('page-hook-ready', { url: location.href }); return; }
    if (data.type === 'CC_PAGE_CONTEXT_INJECTED_V2') {
      const waiter = pageWaiters.get(data.id); if (waiter) { clearTimeout(waiter.timer); pageWaiters.delete(data.id); waiter.resolve({ ok: true }); }
      void diagnostic('context-injected', { chatId: chatId() }); return;
    }
    if (data.type === 'CC_PAGE_CONTEXT_MISSED_V2') {
      const waiter = pageWaiters.get(data.id); if (waiter) { clearTimeout(waiter.timer); pageWaiters.delete(data.id); waiter.resolve({ ok: false, reason: data.reason || 'request payload did not contain prompt' }); }
    }
  });

  async function triggerSend(node) {
    let button = null;
    for (let i = 0; i < 60 && !button; i++) { await sleep(i ? 75 : 30); button = sendButton(node); }
    if (!button) throw new Error('ChatGPT Send button is unavailable.');
    button.click();
  }

  async function sendText(text, { internal = false, attachments = [] } = {}) {
    let node = composer();
    for (let i = 0; i < 40 && !node; i++) { await sleep(100); node = composer(); }
    if (!node) throw new Error('ChatGPT composer is unavailable.');
    if (attachments?.length) await attachFiles(attachments);
    if (!setComposerText(node, text)) throw new Error('Could not stage an internal Commander message in ChatGPT.');
    plumbingSend = internal;
    await triggerSend(node);
    await sleep(150);
    plumbingSend = false;
  }

  function scrubInternalContext() {
    const candidates = [...document.querySelectorAll('[data-message-author-role="user"],article[data-turn="user"],[data-testid^="conversation-turn-"]')];
    for (const node of candidates.slice(-14)) {
      const text = node.textContent || '';
      const contextAt = text.indexOf(CONTEXT_OPEN); const resultAt = text.indexOf(RESULT_OPEN);
      const cut = contextAt >= 0 ? contextAt : resultAt >= 0 ? resultAt : -1;
      if (cut < 0) continue;
      if (resultAt >= 0) { node.style.display = 'none'; node.dataset.constellationCommanderHidden = 'tool-result'; continue; }
      const visible = text.slice(0, cut).trim();
      const leaf = [...node.querySelectorAll('p,div')].find(el => (el.textContent || '').includes(CONTEXT_OPEN));
      if (leaf) leaf.textContent = visible; else node.textContent = visible;
    }
  }

  async function armAndSend(original) {
    if (arming) return;
    arming = true;
    void diagnostic('arm-start', { chatId: chatId(), text: String(original || '').slice(0, 80) });
    try {
      const s = await ensureSession();
      const context = contextText(s);
      const node = composer(); if (!node) throw new Error('ChatGPT composer is unavailable.');
      const hookReady = await waitPageHookReady();
      if (hookReady) {
        const hook = armPageHook(original.trim(), context);
        await triggerSend(node);
        const proof = await hook.promise;
        void diagnostic('arm-hook-proof', { ok: Boolean(proof?.ok), reason: proof?.reason || '', timeout: Boolean(proof?.timeout) });
        if (!proof.ok) throw new Error(`Integrated request hook missed the ChatGPT send: ${proof.reason || 'timeout'}`);
      } else {
        const augmented = `${original.trim()}\n\n${context}`;
        if (!setComposerText(node, augmented)) throw new Error('Integrated request hook was unavailable and ProseMirror fallback failed.');
        await triggerSend(node);
      }
      toast('Commander armed — integrated local tools ready.');
      setTimeout(scrubInternalContext, 200); setTimeout(scrubInternalContext, 900);
    } catch (error) {
      toast(`Commander: ${String(error?.message || error)}`, 'error', true);
      void diagnostic('arm-failed', { error: String(error?.message || error), chatId: chatId() });
    } finally { arming = false; }
  }

  function interceptSend(event) {
    if (plumbingSend || arming) return;
    const node = composer(); if (!node) return;
    const text = getComposerText(node); if (!isLocalIntent(text)) return;
    forceNextPrompt = false;
    void diagnostic('intercept-send', { type: event.type, chatId: chatId(), text: String(text || '').slice(0, 80) });
    event.preventDefault(); event.stopImmediatePropagation(); void armAndSend(text);
  }

  document.addEventListener('submit', interceptSend, true);
  document.addEventListener('click', event => {
    if (plumbingSend || arming) return;
    const node = composer(); const button = node && sendButton(node);
    if (button && (event.target === button || button.contains(event.target))) interceptSend(event);
  }, true);
  document.addEventListener('keydown', event => {
    if (event.key !== 'Enter' || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return;
    const node = composer(); if (node && (event.target === node || node.contains(event.target))) interceptSend(event);
  }, true);

  function extractCall(text) {
    const start = text.indexOf(CALL_OPEN);
    if (start < 0) return { present: false };
    const end = text.indexOf(CALL_CLOSE, start + CALL_OPEN.length);
    if (end < 0) return { present: true, complete: false };
    const raw = text.slice(start + CALL_OPEN.length, end).trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');
    try {
      const parsed = JSON.parse(raw);
      parsed.id ||= crypto.randomUUID?.() || `electron_${Date.now()}_${Math.random().toString(16).slice(2)}`;
      parsed.args = parsed.args && typeof parsed.args === 'object' ? parsed.args : parsed.arguments && typeof parsed.arguments === 'object' ? parsed.arguments : parsed.input && typeof parsed.input === 'object' ? parsed.input : {};
      delete parsed.arguments; delete parsed.input;
      if (!parsed.nonce && session?.nonce) parsed.nonce = session.nonce;
      return { present: true, complete: true, call: parsed };
    } catch (error) { return { present: true, complete: true, error }; }
  }

  async function handleCall(call) {
    if (!call?.id || handledCalls.has(call.id)) return;
    handledCalls.add(call.id);
    try {
      const s = await ensureSession();
      if (!call.nonce) call.nonce = s.nonce;
      if (call.nonce !== s.nonce) { const fresh = await ensureSession(true); call.nonce = fresh.nonce; }
      toast(`Commander running: ${call.tool}`);
      const response = await ipcRenderer.invoke('cc:call', { chatId: chatId(), call });
      const attachments = response?._attachments || [];
      const safe = { ...response }; delete safe._attachments;
      const payload = `${RESULT_OPEN}\n${JSON.stringify({ id: call.id, tool: call.tool, ...safe })}\n${RESULT_CLOSE}`;
      await sendText(payload, { internal: true, attachments });
      const visibleLeak = assistantCandidates().some(node => {
        const text = node.innerText || node.textContent || '';
        if (!text.includes(CALL_OPEN)) return false;
        const style = getComputedStyle(node);
        return style.display !== 'none' && style.visibility !== 'hidden';
      });
      await diagnostic('tool-result-sent', {
        tool: call.tool,
        ok: response?.ok !== false,
        pong: response?.result?.pong === true,
        visibleLeak,
        chatId: chatId()
      });
      setTimeout(scrubInternalContext, 180); setTimeout(scrubInternalContext, 900);
    } catch (error) {
      const message = String(error?.message || error);
      const payload = `${RESULT_OPEN}\n${JSON.stringify({ id: call.id, tool: call.tool, ok: false, error: message })}\n${RESULT_CLOSE}`;
      try { await sendText(payload, { internal: true }); } catch {}
      toast(`Commander tool failed: ${message}`, 'error', true);
      void diagnostic('tool-failed', { error: message, tool: call?.tool || '', chatId: chatId() });
    }
  }

  function assistantCandidates() {
    const explicit = [...document.querySelectorAll('[data-message-author-role="assistant"],article[data-turn="assistant"],[data-testid^="conversation-turn-"]')];
    const markerNodes = [...document.querySelectorAll('main *')].filter(node => node.childElementCount === 0 && (node.textContent || '').includes(CALL_OPEN));
    return [...new Set([...explicit, ...markerNodes.map(node => node.closest('[data-message-author-role="assistant"],article,[data-testid^="conversation-turn-"]') || node)])];
  }

  function scanAssistantCalls() {
    for (const node of assistantCandidates().slice(-24)) {
      const text = node.innerText || node.textContent || '';
      const parsed = extractCall(text);
      if (!parsed.present) continue;
      // Hide as soon as the opening marker streams in so internal control JSON can
      // never visibly leak while ChatGPT is still rendering the rest of the call.
      node.style.visibility = 'hidden';
      node.dataset.constellationCommanderHidden = 'tool-call-pending';
      if (!parsed.complete) continue;
      node.style.display = 'none';
      node.style.visibility = '';
      node.dataset.constellationCommanderHidden = 'tool-call';
      if (parsed.call) {
        if (node.dataset.constellationCommanderCallClaimed === 'true') continue;
        const stableId = node.dataset.constellationCommanderCallId || parsed.call.id;
        node.dataset.constellationCommanderCallId = stableId;
        node.dataset.constellationCommanderCallClaimed = 'true';
        parsed.call.id = stableId;
        void diagnostic('assistant-call-detected', { tool: String(parsed.call.tool || parsed.call.name || ''), id: String(parsed.call.id || '') });
        void handleCall(parsed.call);
      } else toast('Commander received malformed local-call JSON and suppressed it.', 'error', true);
    }
    scrubInternalContext();
  }

  const observer = new MutationObserver(scanAssistantCalls);
  function startAssistantObserver() {
    const root = document.documentElement;
    if (!root) return false;
    observer.observe(root, { childList: true, subtree: true, characterData: true });
    scanAssistantCalls();
    return true;
  }
  if (!startAssistantObserver()) window.addEventListener('DOMContentLoaded', startAssistantObserver, { once: true });

  // Integrated status badge. This is informational only; ChatGPT itself never gets
  // direct IPC or Node access.
  window.addEventListener('DOMContentLoaded', async () => {
    void diagnostic('dom-content-loaded', { url: location.href, readyState: document.readyState });
    try {
      const status = await ipcRenderer.invoke('cc:status');
      if (status?.ok) {
        if (['auto','always','off'].includes(status.localToolMode)) localToolMode = status.localToolMode;
        toast(`Commander ${status.version} ready · local tools ${localToolMode}.`);
      }
    } catch {}
  });

  setInterval(() => {
    if (location.href !== route) { route = location.href; session = null; sessionChatId = ''; }
  }, 500);
})();
