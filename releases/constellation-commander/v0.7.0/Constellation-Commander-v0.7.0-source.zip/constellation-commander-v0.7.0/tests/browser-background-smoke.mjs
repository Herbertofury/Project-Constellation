import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fsp from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { createBrowserBridge } from '../src/browser-bridge.mjs';

const tmp = await fsp.mkdtemp(path.join(os.tmpdir(), 'cc-background-smoke-'));
process.env.CONSTELLATION_COMMANDER_HOME = path.join(tmp, 'commander-home');
process.env.CONSTELLATION_ALLOWED_ROOTS = tmp;
const bridge = await createBrowserBridge({ port: 47721 });
await bridge.start();

const trustedOrigin = 'chrome-extension://khfbmdpkpnaghpfnacidbjfaaikfmanh';
const nativeFetch = globalThis.fetch;
let listener;
let installedListener;
let actionListener;
const reloadedTabs = [];
globalThis.chrome = {
  runtime: {
    id: 'khfbmdpkpnaghpfnacidbjfaaikfmanh',
    onMessage: { addListener(fn) { listener = fn; } },
    onInstalled: { addListener(fn) { installedListener = fn; } }
  },
  action: {
    async setBadgeText() {},
    async setBadgeBackgroundColor() {},
    async setTitle() {},
    onClicked: { addListener(fn) { actionListener = fn; } }
  },
  tabs: {
    async query() { return [{ id: 11, url: 'https://chatgpt.com/c/smoke' }, { id: 12, url: 'https://chat.openai.com/c/legacy' }]; },
    async reload(id) { reloadedTabs.push(id); }
  }
};
globalThis.fetch = (input, init = {}) => {
  const headers = new Headers(init.headers || {});
  headers.set('origin', trustedOrigin);
  return nativeFetch(input, { ...init, headers });
};

async function message(payload) {
  return await new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) reject(new Error(`Background response timeout for ${payload.type}`));
    }, 10000);
    const sendResponse = value => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(value);
    };
    const keepAlive = listener(payload, {}, sendResponse);
    assert.equal(keepAlive, true, `Background must keep ${payload.type} response channel alive`);
  });
}

try {
  await import(`${pathToFileURL(path.resolve('browser-companion/background.js')).href}?smoke=${Date.now()}`);
  assert.equal(typeof listener, 'function', 'background.js must register chrome.runtime.onMessage listener');
  assert.equal(typeof installedListener, 'function', 'background.js must register update/install repair listener');
  assert.equal(typeof actionListener, 'function', 'background.js must register toolbar repair click');
  installedListener({ reason: 'update' });
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.deepEqual(reloadedTabs.slice().sort((a,b)=>a-b), [11,12]);

  await new Promise(resolve => setTimeout(resolve, 80));
  const health = await message({ type: 'CC_HEALTH' });
  assert.equal(health.ok, true);
  assert.equal(health.version, '0.7.0');
  assert.equal(health.quotaEnforced, false);
  assert.equal(health.companionConnected, true);
  assert.equal(health.companionVersion, '0.7.0');
  assert.equal(health.companionVersionMatch, true);

  const diagnostic = await message({ type: 'CC_DIAGNOSTIC', event: 'context-injected', detail: { smoke: true } });
  assert.equal(diagnostic.ok, true);

  const boot = await message({ type: 'CC_BOOTSTRAP', chatId: 'background-smoke', url: 'https://chatgpt.com/c/test' });
  assert.equal(boot.ok, true);
  assert.ok(boot.sessionToken);
  assert.ok(boot.nonce);
  assert.ok(boot.tools.some(tool => tool.name === 'fs_write_text'));

  const proof = path.join(tmp, 'background-proof.txt');
  const write = await message({
    type: 'CC_CALL',
    sessionToken: boot.sessionToken,
    call: { nonce: boot.nonce, id: 'background-write', tool: 'fs_write_text', args: { path: proof, content: 'background-proof', mode: 'rewrite' } }
  });
  assert.equal(write.ok, true, JSON.stringify(write));
  assert.equal(await fsp.readFile(proof, 'utf8'), 'background-proof');

  const read = await message({
    type: 'CC_CALL',
    sessionToken: boot.sessionToken,
    call: { nonce: boot.nonce, id: 'background-read', tool: 'fs_read_text', args: { path: proof, offset: 0, length: 20 } }
  });
  assert.equal(read.ok, true, JSON.stringify(read));
  assert.match(JSON.stringify(read), /background-proof/);

  console.log('Constellation Commander browser background -> real bridge smoke: PASS');
} finally {
  globalThis.fetch = nativeFetch;
  delete globalThis.chrome;
  await bridge.stop();
  await fsp.rm(tmp, { recursive: true, force: true });
}
