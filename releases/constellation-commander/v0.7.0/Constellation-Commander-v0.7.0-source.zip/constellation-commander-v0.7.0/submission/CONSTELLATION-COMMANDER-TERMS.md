# Constellation Commander Terms of Use

Constellation Commander is provided under the MIT License and is intended for computers and data the user is authorized to access.

Users are responsible for configuring allowed filesystem roots, blocked commands, relay credentials, hosting security, and device access appropriately. Computer-control tools can modify files and terminate processes; review important actions and maintain backups for valuable data.

The software is provided "AS IS", without warranty of any kind, consistent with the included MIT License. Do not use Constellation Commander to access systems without authorization or to bypass security controls you are not authorized to change.

Project support and source are available at https://github.com/Herbertofury/Project-Constellation
