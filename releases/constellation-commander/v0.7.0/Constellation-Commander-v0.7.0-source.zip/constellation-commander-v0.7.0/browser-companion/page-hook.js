(() => {
  const SOURCE = 'constellation-commander-page-hook';
  const ARM_TYPE = 'CC_ARM_CONTEXT_V2';
  const READY_TYPE = 'CC_PAGE_HOOK_READY_V2';
  const ARMED_TYPE = 'CC_PAGE_CONTEXT_ARMED_V2';
  const INJECTED_TYPE = 'CC_PAGE_CONTEXT_INJECTED_V2';
  const MISSED_TYPE = 'CC_PAGE_CONTEXT_MISSED_V2';
  const MAX_PENDING_MS = 15000;
  let pending = null;

  const normalize = value => String(value ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const now = () => Date.now();
  const post = (type, extra = {}) => {
    try { window.postMessage({ source: SOURCE, type, ...extra }, '*'); } catch {}
  };

  function isUserLike(value) {
    if (!value || typeof value !== 'object') return false;
    const role = String(value.role || value.author?.role || value.message?.author?.role || '').toLowerCase();
    return role === 'user';
  }

  function scorePath(path, ancestors) {
    const joined = path.join('.').toLowerCase();
    let score = 0;
    if (ancestors.some(isUserLike)) score += 100;
    if (/messages|input|conversation|content|parts/.test(joined)) score += 30;
    if (/text|content|parts/.test(String(path.at(-1) || '').toLowerCase())) score += 20;
    return score;
  }

  function collectExactStringCandidates(node, original, path = [], ancestors = [], out = []) {
    if (typeof node === 'string') {
      if (normalize(node) === original) out.push({ parent: ancestors.at(-1), key: path.at(-1), path: [...path], score: scorePath(path, ancestors), value: node });
      return out;
    }
    if (!node || typeof node !== 'object') return out;
    const nextAncestors = [...ancestors, node];
    if (Array.isArray(node)) {
      for (let i = 0; i < node.length; i++) collectExactStringCandidates(node[i], original, [...path, i], nextAncestors, out);
    } else {
      for (const [key, value] of Object.entries(node)) collectExactStringCandidates(value, original, [...path, key], nextAncestors, out);
    }
    return out;
  }

  function containsArmedContext(node, originalText) {
    const original = normalize(originalText);
    let found = false;
    const visit = value => {
      if (found) return;
      if (typeof value === 'string') {
        const normalized = normalize(value);
        if (value.includes('[PROJECT CONSTELLATION LOCAL CONTEXT]') && (!original || normalized.includes(original))) found = true;
        return;
      }
      if (!value || typeof value !== 'object') return;
      if (Array.isArray(value)) for (const item of value) visit(item);
      else for (const item of Object.values(value)) visit(item);
    };
    visit(node);
    return found;
  }

  function appendToBestCandidate(payload, originalText, context) {
    const original = normalize(originalText);
    if (!original || !context) return false;
    if (containsArmedContext(payload, originalText)) return true;
    const candidates = collectExactStringCandidates(payload, original).filter(candidate => candidate.parent != null);
    if (!candidates.length) return false;
    candidates.sort((a, b) => b.score - a.score || b.path.length - a.path.length);
    const best = candidates[0];
    // Refuse a weak telemetry/metadata match. The real prompt normally lives under
    // a user/message/input/content path and scores well above this threshold.
    if (best.score < 30) return false;
    if (String(best.value).includes('[PROJECT CONSTELLATION LOCAL CONTEXT]')) return true;
    best.parent[best.key] = `${best.value}\n\n${context}`;
    return true;
  }

  function activePending() {
    if (!pending) return null;
    if (pending.used || pending.expiresAt <= now()) { pending = null; return null; }
    return pending;
  }

  function transformBody(body) {
    const item = activePending();
    if (!item || typeof body !== 'string' || body.length < 2 || body.length > 8 * 1024 * 1024) return { body, injected: false };
    let parsed;
    try { parsed = JSON.parse(body); } catch { return { body, injected: false }; }
    if (!appendToBestCandidate(parsed, item.original, item.context)) return { body, injected: false };
    item.used = true;
    post(INJECTED_TYPE, { id: item.id, url: location.href });
    return { body: JSON.stringify(parsed), injected: true };
  }

  function arm(data) {
    const id = String(data?.id || '').trim();
    const original = String(data?.original || '').trim();
    const context = String(data?.context || '').trim();
    if (!id || !original || !context) return;
    pending = { id, original, context, used: false, expiresAt: now() + MAX_PENDING_MS };
    post(ARMED_TYPE, { id });
  }

  window.addEventListener('message', event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'constellation-commander-content' || data.type !== ARM_TYPE) return;
    arm(data);
  });

  const originalFetch = window.fetch.bind(window);
  window.fetch = async function constellationCommanderFetch(input, init) {
    const item = activePending();
    if (!item) return originalFetch(input, init);
    try {
      const request = input instanceof Request ? input : null;
      const method = String(init?.method || request?.method || 'GET').toUpperCase();
      if (method !== 'POST') return originalFetch(input, init);

      if (typeof init?.body === 'string') {
        const changed = transformBody(init.body);
        if (changed.injected) return originalFetch(input, { ...init, body: changed.body });
        return originalFetch(input, init);
      }

      if (request && !init?.body) {
        const type = request.headers.get('content-type') || '';
        if (!/json/i.test(type)) return originalFetch(input, init);
        const text = await request.clone().text();
        const changed = transformBody(text);
        if (changed.injected) {
          const replacement = new Request(request, { body: changed.body });
          return originalFetch(replacement, init);
        }
      }
    } catch (error) {
      post(MISSED_TYPE, { id: item.id, reason: String(error?.message || error) });
    }
    return originalFetch(input, init);
  };

  if (typeof XMLHttpRequest !== 'undefined') {
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__ccMethod = String(method || 'GET').toUpperCase();
      this.__ccUrl = String(url || '');
      return originalOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      if (activePending() && this.__ccMethod === 'POST' && typeof body === 'string') {
        try {
          const changed = transformBody(body);
          if (changed.injected) return originalSend.call(this, changed.body);
        } catch (error) {
          post(MISSED_TYPE, { id: pending?.id || '', reason: String(error?.message || error) });
        }
      }
      return originalSend.call(this, body);
    };
  }

  post(READY_TYPE, { version: '0.7.0' });
})();
