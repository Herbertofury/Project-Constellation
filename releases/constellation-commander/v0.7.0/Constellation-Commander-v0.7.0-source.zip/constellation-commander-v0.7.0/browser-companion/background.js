const BASE = 'http://127.0.0.1:47721';
const VERSION = '0.7.0';

async function bridge(path, { method = 'GET', body = null, token = '' } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(token ? { authorization: `Bearer ${token}` } : {})
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal
    });
    const data = await response.json().catch(() => ({ ok: false, error: `HTTP ${response.status}` }));
    return { status: response.status, ...data };
  } finally {
    clearTimeout(timer);
  }
}

async function setBadge(state) {
  try {
    if (state === 'ready') {
      await chrome.action.setBadgeText({ text: 'ON' });
      await chrome.action.setBadgeBackgroundColor({ color: '#16803c' });
      await chrome.action.setTitle({ title: `Constellation Commander ${VERSION} — connected` });
    } else if (state === 'stale') {
      await chrome.action.setBadgeText({ text: 'UPD' });
      await chrome.action.setBadgeBackgroundColor({ color: '#b45309' });
      await chrome.action.setTitle({ title: `Constellation Commander ${VERSION} — reload/update required` });
    } else {
      await chrome.action.setBadgeText({ text: 'OFF' });
      await chrome.action.setBadgeBackgroundColor({ color: '#991b1b' });
      await chrome.action.setTitle({ title: `Constellation Commander ${VERSION} — local app offline` });
    }
  } catch {}
}

async function announceCompanion() {
  try {
    const response = await bridge('/v1/companion/hello', {
      method: 'POST',
      body: { version: VERSION, extensionId: chrome.runtime.id }
    });
    if (response?.versionMismatch) await setBadge('stale');
    else if (response?.ok) await setBadge('ready');
    else await setBadge('offline');
    return response;
  } catch {
    await setBadge('offline');
    return { ok: false, offline: true };
  }
}


async function refreshChatGptTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: ['https://chatgpt.com/*', 'https://chat.openai.com/*'] });
    const tasks = tabs.filter(tab => Number.isInteger(tab.id)).map(tab => chrome.tabs.reload(tab.id));
    await Promise.allSettled(tasks);
  } catch {}
}

chrome.runtime.onInstalled.addListener(({ reason }) => {
  // Chrome documents unpacked-extension Reload as an update. Reload existing
  // ChatGPT tabs so the new MAIN/ISOLATED scripts are active immediately instead
  // of leaving an invalidated old content script in a tab that looks connected.
  if (reason === 'install' || reason === 'update') void refreshChatGptTabs();
});

chrome.action.onClicked.addListener(tab => {
  // Toolbar click is a simple repair action for the current ChatGPT tab.
  if (Number.isInteger(tab?.id) && /^https:\/\/(?:chatgpt\.com|chat\.openai\.com)\//i.test(String(tab.url || ''))) {
    void chrome.tabs.reload(tab.id);
  }
});

void announceCompanion();
const companionHeartbeat = setInterval(() => { void announceCompanion(); }, 5000);
companionHeartbeat.unref?.();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === 'CC_HEALTH') return sendResponse(await bridge('/health'));
      if (message?.type === 'CC_BOOTSTRAP') {
        const result = await bridge('/v1/session/bootstrap', { method: 'POST', body: { chatId: message.chatId, url: message.url } });
        if (result?.versionMismatch) await setBadge('stale');
        return sendResponse(result);
      }
      if (message?.type === 'CC_REFRESH') {
        return sendResponse(await bridge('/v1/session/refresh', { method: 'POST', token: message.sessionToken, body: { nonce: message.nonce } }));
      }
      if (message?.type === 'CC_CALL') {
        return sendResponse(await bridge('/v1/session/call', { method: 'POST', token: message.sessionToken, body: message.call }));
      }
      if (message?.type === 'CC_DIAGNOSTIC') {
        return sendResponse(await bridge('/v1/companion/event', { method: 'POST', body: { event: message.event, detail: message.detail || null, at: new Date().toISOString() } }));
      }
      sendResponse({ ok: false, error: 'Unknown companion message.' });
    } catch (error) {
      sendResponse({ ok: false, error: String(error?.message || error), offline: true });
    }
  })();
  return true;
});
