import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let helperPath = path.resolve(__dirname, '../native/windows-computer-use.ps1');
if (helperPath.includes('app.asar')) helperPath = helperPath.replace('app.asar', 'app.asar.unpacked');
let child = null;
let stdoutBuffer = '';
let stderrBuffer = '';
const pending = new Map();

function failAll(error) {
  for (const { reject, timer } of pending.values()) { clearTimeout(timer); reject(error); }
  pending.clear();
}

function ensureWindows() {
  if (process.platform !== 'win32') throw new Error('Full computer-use controls are currently implemented for Windows only.');
}

function startHelper() {
  ensureWindows();
  if (child && !child.killed && child.exitCode == null) return child;
  child = spawn('powershell.exe', ['-NoLogo','-NoProfile','-Sta','-ExecutionPolicy','Bypass','-File',helperPath], {
    stdio: ['pipe','pipe','pipe'], windowsHide: true
  });
  stdoutBuffer = ''; stderrBuffer = '';
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', chunk => {
    stdoutBuffer += chunk;
    for (;;) {
      const idx = stdoutBuffer.indexOf('\n');
      if (idx < 0) break;
      const line = stdoutBuffer.slice(0, idx).trim(); stdoutBuffer = stdoutBuffer.slice(idx + 1);
      if (!line) continue;
      let msg; try { msg = JSON.parse(line); } catch { continue; }
      const slot = pending.get(msg.id); if (!slot) continue;
      pending.delete(msg.id); clearTimeout(slot.timer);
      if (msg.ok) slot.resolve(msg.result); else slot.reject(new Error(msg.error || 'Computer-use helper failed.'));
    }
  });
  child.stderr.on('data', chunk => { stderrBuffer = (stderrBuffer + chunk).slice(-32768); });
  child.on('error', error => failAll(error));
  child.on('exit', (code, signal) => { const detail = stderrBuffer.trim(); failAll(new Error(`Computer-use helper exited (${code ?? signal})${detail ? `: ${detail}` : ''}`)); child = null; });
  return child;
}

export async function computerUse(command, args = {}, timeoutMs = 20000) {
  const proc = startHelper();
  const id = crypto.randomBytes(10).toString('hex');
  return await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`Computer-use command timed out: ${command}`)); }, Math.max(1000, timeoutMs));
    pending.set(id, { resolve, reject, timer });
    proc.stdin.write(JSON.stringify({ id, command, args }) + '\n', 'utf8', error => {
      if (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  });
}

export async function closeComputerUseHelper() {
  if (!child) return;
  const old = child; child = null;
  try { old.stdin.end(); } catch {}
  setTimeout(() => { try { if (old.exitCode == null) old.kill(); } catch {} }, 500).unref();
}
