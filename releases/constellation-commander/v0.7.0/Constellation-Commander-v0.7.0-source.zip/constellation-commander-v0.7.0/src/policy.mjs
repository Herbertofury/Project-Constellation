import path from 'node:path';
import os from 'node:os';

function norm(p) {
  const r = path.resolve(p.replace(/^~(?=$|[\\/])/, os.homedir()));
  return process.platform === 'win32' ? r.toLowerCase() : r;
}

export function resolveUserPath(p) {
  if (typeof p !== 'string' || !p.trim()) throw new Error('path must be a non-empty string');
  return path.resolve(p.replace(/^~(?=$|[\\/])/, os.homedir()));
}

export function assertAllowedPath(p, config) {
  const resolved = resolveUserPath(p);
  if (config.allowedRoots?.includes('*')) return resolved;
  const rp = norm(resolved);
  const allowed = (config.allowedRoots || []).some(root => {
    const rr = norm(root);
    return rp === rr || rp.startsWith(rr + path.sep);
  });
  if (!allowed) throw new Error(`Path is outside allowed roots: ${resolved}`);
  return resolved;
}

export function assertCommandAllowed(command, config) {
  if (!config.enableShell) throw new Error('Shell execution is disabled in configuration.');
  for (const item of config.blockedCommands || []) {
    if (!item) continue;
    const re = new RegExp(item, 'i');
    if (re.test(command)) throw new Error(`Command blocked by configuration rule: ${item}`);
  }
}
