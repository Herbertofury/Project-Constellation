import path from 'node:path';
import fsp from 'node:fs/promises';

export function createRuntimeState(baseDir) {
  return {
    baseDir,
    processes: new Map(),
    searches: new Map(),
    shutdownRequested: false,
    callsPath: path.join(baseDir, 'tool-calls.jsonl'),
    statsPath: path.join(baseDir, 'stats.json')
  };
}

export async function recordCall(state, entry) {
  const line = JSON.stringify({ ts: new Date().toISOString(), ...entry }) + '\n';
  await fsp.appendFile(state.callsPath, line).catch(() => {});
  let stats = { totalCalls: 0, byTool: {}, errors: 0 };
  try { stats = JSON.parse(await fsp.readFile(state.statsPath, 'utf8')); } catch {}
  stats.totalCalls = (stats.totalCalls || 0) + 1;
  stats.byTool ||= {};
  stats.byTool[entry.tool] = (stats.byTool[entry.tool] || 0) + 1;
  if (!entry.ok) stats.errors = (stats.errors || 0) + 1;
  await fsp.writeFile(state.statsPath, JSON.stringify(stats, null, 2)).catch(() => {});
}
