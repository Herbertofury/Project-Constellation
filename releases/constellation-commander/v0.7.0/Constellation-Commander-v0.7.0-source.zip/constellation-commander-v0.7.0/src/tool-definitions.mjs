const obj = (properties = {}, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
const str = (description) => ({ type: 'string', description });
const num = (description) => ({ type: 'number', description });
const bool = (description) => ({ type: 'boolean', description });

const tool = (name, description, inputSchema, annotations = {}) => ({
  name, title: name.replaceAll('_', ' '), description, inputSchema,
  annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false, ...annotations }
});

export function toolDefinitions() {
  return [
    tool('list_devices', 'List devices available through this self-hosted commander. Reports the machine running this Commander instance as the local device.', obj(), { readOnlyHint: true, idempotentHint: true }),
    tool('who_am_i', 'Describe the local self-hosted commander identity and quota policy. No external account is required.', obj(), { readOnlyHint: true, idempotentHint: true }),
    tool('ping', 'Verify that Constellation Commander is online and identify the connected machine.', obj(), { readOnlyHint: true, idempotentHint: true }),
    tool('get_system_info', 'Return operating system, Node runtime, hostname, home directory, and commander version.', obj(), { readOnlyHint: true, idempotentHint: true }),
    tool('get_config', 'Read current Constellation Commander configuration. Secrets are redacted.', obj(), { readOnlyHint: true, idempotentHint: true }),
    tool('set_config_value', 'Set a supported configuration key. Use allowedRoots=["*"] only when the user intentionally grants full filesystem access.', obj({ key: str('Configuration key'), value: {} }, ['key','value'])),
    tool('read_file', 'Read a file. Text is returned as UTF-8; binary files can be returned as base64. Supports line offset/length for text.', obj({ path: str('Absolute or ~ path'), offset: num('0-based line offset; negative reads from end'), length: num('Maximum lines'), encoding: { type:'string', enum:['utf8','base64'] } }, ['path']), { readOnlyHint: true, idempotentHint: true }),
    tool('read_multiple_files', 'Read multiple files in one call.', obj({ paths: { type:'array', items:{type:'string'} } }, ['paths']), { readOnlyHint: true, idempotentHint: true }),
    tool('write_file', 'Create, overwrite, or append a text/base64 file.', obj({ path: str('Target path'), content: str('File content'), mode: {type:'string',enum:['rewrite','append']}, encoding:{type:'string',enum:['utf8','base64']} }, ['path','content'])),
    tool('edit_block', 'Replace an exact text block in a file. Fails when the expected block is absent or replacement count is unexpected.', obj({ path:str('File path'), old_string:str('Exact existing text'), new_string:str('Replacement text'), expected_replacements:num('Expected number of replacements') }, ['path','old_string','new_string'])),
    tool('write_pdf', 'Create a new text PDF without external dependencies. Creates a new text PDF; existing-PDF editing is not exposed by this tool.', obj({ path:str('Output PDF path'), content:str('Text or lightweight Markdown content') }, ['path','content'])),
    tool('create_directory', 'Create a directory recursively.', obj({ path:str('Directory path') }, ['path'])),
    tool('list_directory', 'List files and directories recursively to a requested depth.', obj({ path:str('Directory path'), depth:num('Depth, default 1') }, ['path']), { readOnlyHint:true, idempotentHint:true }),
    tool('get_file_info', 'Return stat information for a file or directory.', obj({ path:str('Path') }, ['path']), { readOnlyHint:true, idempotentHint:true }),
    tool('copy_file', 'Copy a file or directory recursively.', obj({ source:str('Source'), destination:str('Destination'), overwrite:bool('Allow replacing destination') }, ['source','destination'])),
    tool('move_file', 'Move or rename a file or directory.', obj({ source:str('Source'), destination:str('Destination'), overwrite:bool('Allow replacing destination') }, ['source','destination'])),
    tool('trash_path', 'Move a file or directory to the operating system recycle bin/trash when supported. Never silently falls back to permanent deletion.', obj({ path:str('Path') }, ['path']), { destructiveHint:true }),
    tool('open_path', 'Open a file, folder, URL, or application using the operating system default handler.', obj({ path:str('Local path or URL') }, ['path'])),
    tool('start_search', 'Start an asynchronous recursive filename/content search and return a search id immediately.', obj({ path:str('Root directory'), query:str('Text or regex query'), mode:{type:'string',enum:['name','content','both']}, regex:bool('Treat query as regex'), case_sensitive:bool('Case sensitive match') }, ['path','query'])),
    tool('get_more_search_results', 'Read the next page of results from an active or completed search.', obj({ search_id:str('Search id'), offset:num('Result offset'), limit:num('Max results') }, ['search_id']), { readOnlyHint:true }),
    tool('list_searches', 'List active and recent searches.', obj(), { readOnlyHint:true }),
    tool('stop_search', 'Cancel an active search.', obj({ search_id:str('Search id') }, ['search_id'])),
    tool('start_process', 'Start a local command or interactive process. Output is durably spooled so it can be read later.', obj({ command:str('Command to run'), cwd:str('Working directory'), shell:str('Optional shell override'), timeout_ms:num('Optional timeout; 0 means no timeout') }, ['command'])),
    tool('read_process_output', 'Read output from a commander-started process. offset=0 returns output since the prior read; negative reads from end.', obj({ session_id:str('Commander session id'), offset:num('Line offset; 0=new output, negative=tail'), length:num('Maximum lines'), wait_ms:num('Wait briefly for new output') }, ['session_id']), { readOnlyHint:true }),
    tool('interact_with_process', 'Write input to a running interactive process and return newly available output.', obj({ session_id:str('Commander session id'), input:str('Input text'), wait_ms:num('Wait for response') }, ['session_id','input'])),
    tool('list_sessions', 'List terminal sessions started by Constellation Commander.', obj(), { readOnlyHint:true }),
    tool('force_terminate', 'Terminate a commander-started process session.', obj({ session_id:str('Commander session id') }, ['session_id']), { destructiveHint:true }),
    tool('list_processes', 'List system processes with PID and command/name.', obj(), { readOnlyHint:true }),
    tool('kill_process', 'Force terminate a system process by PID.', obj({ pid:num('Process ID') }, ['pid']), { destructiveHint:true }),
    tool('computer_displays', 'List connected displays, virtual-screen coordinates, dimensions, work areas, and primary display.', obj(), { readOnlyHint:true, idempotentHint:true }),
    tool('computer_windows', 'List visible top-level windows with handles, titles, processes, bounds, minimized state, and foreground state.', obj({ limit:num('Maximum windows to return') }), { readOnlyHint:true, idempotentHint:true }),
    tool('computer_cursor', 'Return the current mouse cursor position in virtual-screen coordinates.', obj(), { readOnlyHint:true, idempotentHint:true }),
    tool('computer_observe', 'Observe the current desktop in one call: displays, cursor, visible windows, and a fresh screenshot returned as an actual image attachment. Use this before/after visual actions when state is uncertain.', obj({ max_width:num('Screenshot maximum width'), max_height:num('Screenshot maximum height'), window_limit:num('Maximum top-level windows') }), { readOnlyHint:true }),
    tool('computer_screenshot', 'Capture the whole virtual desktop, one monitor, one window, or a screen region. Returns an actual image attachment to capable clients plus dimensions/coordinates.', obj({ target:{type:'string',enum:['all','monitor','window','region']}, monitor:num('0-based monitor index'), handle:{description:'Window handle (decimal or 0x hex)'}, title:str('Window title substring when target=window'), pid:num('Window process id'), x:num('Region x'), y:num('Region y'), width:num('Region width'), height:num('Region height'), max_width:num('Resize maximum width; default 1600'), max_height:num('Resize maximum height; default 1200'), format:{type:'string',enum:['jpeg','png']} }), { readOnlyHint:true }),
    tool('computer_move_mouse', 'Move the mouse pointer to absolute virtual-screen coordinates.', obj({ x:num('Screen x'), y:num('Screen y') }, ['x','y'])),
    tool('computer_click', 'Click at coordinates or the current cursor position.', obj({ x:num('Optional screen x'), y:num('Optional screen y'), button:{type:'string',enum:['left','right','middle']} })),
    tool('computer_double_click', 'Double-click at coordinates or the current cursor position.', obj({ x:num('Optional screen x'), y:num('Optional screen y'), button:{type:'string',enum:['left','right','middle']} })),
    tool('computer_drag', 'Drag with the left mouse button from one coordinate to another.', obj({ from_x:num('Start x'), from_y:num('Start y'), to_x:num('End x'), to_y:num('End y'), steps:num('Interpolation steps') }, ['from_x','from_y','to_x','to_y'])),
    tool('computer_scroll', 'Scroll vertically or horizontally. Positive amount scrolls up/right, negative down/left.', obj({ amount:num('Wheel notches'), horizontal:bool('Horizontal scroll') }, ['amount'])),
    tool('computer_keypress', 'Press and release one keyboard key, optionally repeatedly.', obj({ key:str('Key name such as enter, tab, esc, left, f5, a'), repeat:num('Repeat count') }, ['key'])),
    tool('computer_hotkey', 'Press a keyboard chord such as ctrl+l, alt+tab, win+r, or ctrl+shift+esc.', obj({ keys:{type:'array',items:{type:'string'},minItems:1} }, ['keys'])),
    tool('computer_type', 'Type arbitrary Unicode text into the focused application using a clipboard-preserving paste path.', obj({ text:str('Text to type'), settle_ms:num('Delay before clipboard restoration') }, ['text'])),
    tool('computer_wait', 'Wait for desktop UI/state to settle before the next observation or action.', obj({ ms:num('Milliseconds to wait; default 500') })),
    tool('computer_actions', 'Execute a grouped sequence of computer-use actions (move, click, double_click, drag, scroll, keypress, hotkey, type, wait) with one round trip, optionally returning a fresh screenshot afterward.', obj({ actions:{type:'array',items:{type:'object',additionalProperties:true},minItems:1}, screenshot_after:bool('Capture fresh screenshot after actions'), screenshot:{type:'object',additionalProperties:true} }, ['actions'])),
    tool('computer_focus_window', 'Restore and focus a window selected by handle, title substring, or PID.', obj({ handle:{}, title:str('Window title substring'), pid:num('Process id') })),
    tool('computer_window_state', 'Restore, minimize, or maximize a window.', obj({ handle:{}, title:str('Window title substring'), pid:num('Process id'), state:{type:'string',enum:['restore','minimize','maximize']} }, ['state'])),
    tool('computer_close_window', 'Request that a top-level window close normally (WM_CLOSE).', obj({ handle:{}, title:str('Window title substring'), pid:num('Process id') }), { destructiveHint:true }),
    tool('computer_clipboard_read', 'Read text currently on the Windows clipboard.', obj(), { readOnlyHint:true }),
    tool('computer_clipboard_write', 'Replace clipboard text.', obj({ text:str('Clipboard text') }, ['text'])),
    tool('computer_click_ui_element', 'Find the first Windows UI Automation element matching semantic criteria and click the center of its bounding rectangle, optionally returning a fresh screenshot.', obj({ query:str('Substring matched across element metadata'), name:str('Accessible name substring'), automation_id:str('Exact AutomationId'), class_name:str('Class name substring'), control_type:str('Control type substring'), window_handle:{}, max_depth:num('Automation tree depth'), screenshot_after:bool('Return a fresh screenshot after the click') })),
    tool('computer_find_ui_elements', 'Inspect Windows UI Automation elements by name, automation id, class, control type, or general query. Returns bounds that can be clicked directly.', obj({ query:str('Substring matched across element metadata'), name:str('Accessible name substring'), automation_id:str('Exact AutomationId'), class_name:str('Class name substring'), control_type:str('Control type substring such as Button/Edit/MenuItem'), window_handle:{}, max_results:num('Maximum matches'), max_depth:num('Automation tree depth') }), { readOnlyHint:true }),
    tool('get_recent_tool_calls', 'Return recent persisted Commander tool calls for cross-chat continuity. Arguments are redacted to a compact summary.', obj({ max_results:num('Maximum entries') }, []), { readOnlyHint:true }),
    tool('get_usage_stats', 'Return local usage counters only. Constellation Commander never enforces quotas from these counters.', obj(), { readOnlyHint:true, idempotentHint:true }),
    tool('shutdown', 'Gracefully stop the Constellation Commander server after responding.', obj(), { destructiveHint:true })
  ];
}
