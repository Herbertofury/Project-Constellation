import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { APP_NAME, VERSION, saveConfig } from './config.mjs';
import { assertAllowedPath, assertCommandAllowed, resolveUserPath } from './policy.mjs';
import { recordCall } from './state.mjs';
import { computerUse, closeComputerUseHelper } from './computer-use.mjs';

const execFileAsync = promisify(execFile);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const now = () => new Date().toISOString();
const id = prefix => `${prefix}_${crypto.randomBytes(8).toString('hex')}`;

function redactConfig(config) {
  const out = { ...config };
  for (const key of Object.keys(out)) {
    if (/token|secret|password/i.test(key)) out[key] = '<redacted>';
  }
  return out;
}

function linesSlice(text, offset = 0, length = 1000, cursor = 0) {
  const lines = text.split(/\r?\n/);
  if (offset < 0) return { lines: lines.slice(Math.max(0, lines.length + offset)), next: lines.length };
  const start = offset === 0 ? cursor : offset;
  const end = length && length > 0 ? Math.min(lines.length, start + length) : lines.length;
  return { lines: lines.slice(start, end), next: end };
}

async function listDir(root, depth, current = 0, out = []) {
  const entries = await fsp.readdir(root, { withFileTypes: true });
  entries.sort((a,b) => a.name.localeCompare(b.name));
  for (const e of entries) {
    const p = path.join(root, e.name);
    out.push({ type: e.isDirectory() ? 'directory' : e.isFile() ? 'file' : 'other', path: p, name: e.name });
    if (e.isDirectory() && current + 1 < depth) {
      try { await listDir(p, depth, current + 1, out); } catch (err) { out.push({ type:'denied', path:p, error:String(err.message || err) }); }
    }
  }
  return out;
}

function matchText(value, query, regex, caseSensitive) {
  if (regex) return new RegExp(query, caseSensitive ? '' : 'i').test(value);
  return caseSensitive ? value.includes(query) : value.toLowerCase().includes(query.toLowerCase());
}

async function runSearchJob(job, config) {
  const ignore = new Set(config.searchIgnore || []);
  const walk = async dir => {
    if (job.cancelled) return;
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); }
    catch { return; }
    for (const e of entries) {
      if (job.cancelled) return;
      if (ignore.has(e.name)) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { await walk(p); continue; }
      if (!e.isFile()) continue;
      let matched = false;
      let excerpt = '';
      if (job.mode === 'name' || job.mode === 'both') matched = matchText(e.name, job.query, job.regex, job.caseSensitive);
      if (!matched && (job.mode === 'content' || job.mode === 'both')) {
        try {
          const st = await fsp.stat(p);
          if (st.size <= 16 * 1024 * 1024) {
            const buf = await fsp.readFile(p);
            if (!buf.includes(0)) {
              const text = buf.toString('utf8');
              matched = matchText(text, job.query, job.regex, job.caseSensitive);
              if (matched) {
                const idx = job.caseSensitive ? text.indexOf(job.query) : text.toLowerCase().indexOf(job.query.toLowerCase());
                excerpt = idx >= 0 ? text.slice(Math.max(0, idx - 120), Math.min(text.length, idx + 240)).replace(/\s+/g,' ') : '';
              }
            }
          }
        } catch {}
      }
      if (matched) {
        await fsp.appendFile(job.resultsPath, JSON.stringify({ path:p, excerpt }) + '\n');
        job.count++;
      }
    }
  };
  try { await walk(job.root); job.status = job.cancelled ? 'cancelled' : 'complete'; }
  catch (e) { job.status = 'error'; job.error = String(e.message || e); }
  job.finishedAt = now();
}


function simplePdfBuffer(content) {
  const clean = String(content).replace(/\r/g,'').replace(/^#{1,6}\s+/gm,'').replace(/\*\*/g,'').replace(/`/g,'');
  const rawLines = clean.split('\n');
  const wrapped = [];
  for (const line of rawLines) {
    if (!line) { wrapped.push(''); continue; }
    let rest=line;
    while (rest.length > 92) {
      let cut=rest.lastIndexOf(' ',92); if(cut<20)cut=92;
      wrapped.push(rest.slice(0,cut)); rest=rest.slice(cut).trimStart();
    }
    wrapped.push(rest);
  }
  const pages=[]; for(let i=0;i<wrapped.length;i+=54)pages.push(wrapped.slice(i,i+54));
  if(!pages.length)pages.push(['']);
  const esc = t => t.replace(/[^\x20-\x7E]/g,'?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');
  const objects = new Map();
  const pageIds=[];
  objects.set(1,'<< /Type /Catalog /Pages 2 0 R >>');
  objects.set(3,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  pages.forEach((lines,i)=>{
    const pid=4+i*2,cid=5+i*2; pageIds.push(pid);
    const ops=['BT','/F1 10 Tf','50 760 Td','12 TL',...lines.flatMap((line,j)=>[(j?'T*':''),`(${esc(line)}) Tj`].filter(Boolean)),'ET'].join('\n');
    objects.set(pid,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents ${cid} 0 R >>`);
    objects.set(cid,`<< /Length ${Buffer.byteLength(ops,'ascii')} >>\nstream\n${ops}\nendstream`);
  });
  objects.set(2,`<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map(x=>`${x} 0 R`).join(' ')}] >>`);
  const max=Math.max(...objects.keys()); let pdf='%PDF-1.4\n%CCMD\n'; const offsets=[0];
  for(let i=1;i<=max;i++){ offsets[i]=Buffer.byteLength(pdf,'ascii'); pdf+=`${i} 0 obj\n${objects.get(i)||'<<>>'}\nendobj\n`; }
  const xref=Buffer.byteLength(pdf,'ascii'); pdf+=`xref\n0 ${max+1}\n0000000000 65535 f \n`;
  for(let i=1;i<=max;i++)pdf+=`${String(offsets[i]).padStart(10,'0')} 00000 n \n`;
  pdf+=`trailer\n<< /Size ${max+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf,'ascii');
}

async function trashPath(target) {
  if (process.platform === 'win32') {
    const escaped = target.replaceAll("'", "''");
    const script = `Add-Type -AssemblyName Microsoft.VisualBasic; $p='${escaped}'; if (Test-Path -LiteralPath $p -PathType Container) { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($p,'OnlyErrorDialogs','SendToRecycleBin') } else { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p,'OnlyErrorDialogs','SendToRecycleBin') }`;
    await execFileAsync('powershell.exe', ['-NoProfile','-NonInteractive','-Command', script]);
    return;
  }
  for (const cmd of [['gio',['trash',target]],['trash-put',[target]]]) {
    try { await execFileAsync(cmd[0], cmd[1]); return; } catch {}
  }
  throw new Error('No supported recycle-bin command is available; refusing permanent deletion.');
}

async function openPath(target) {
  if (/^https?:\/\//i.test(target)) {
    if (process.platform === 'win32') return execFileAsync('cmd.exe',['/c','start','',target]);
    if (process.platform === 'darwin') return execFileAsync('open',[target]);
    return execFileAsync('xdg-open',[target]);
  }
  if (process.platform === 'win32') return execFileAsync('cmd.exe',['/c','start','',target]);
  if (process.platform === 'darwin') return execFileAsync('open',[target]);
  return execFileAsync('xdg-open',[target]);
}

function shellSpec(command, shellOverride, config) {
  const shell = shellOverride || config.defaultShell;
  if (process.platform === 'win32') {
    if ((shell || '').toLowerCase().includes('cmd')) return { exe:'cmd.exe', args:['/d','/s','/c',command] };
    return { exe:'powershell.exe', args:['-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-Command',command] };
  }
  return { exe: shell || '/bin/bash', args:['-lc',command] };
}

async function processLines(session) {
  let text = '';
  try { text = await fsp.readFile(session.logPath, 'utf8'); } catch {}
  return text;
}

async function listSystemProcesses() {
  if (process.platform === 'win32') {
    const { stdout } = await execFileAsync('powershell.exe',['-NoProfile','-NonInteractive','-Command',"Get-CimInstance Win32_Process | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress"], { maxBuffer: 32*1024*1024 });
    const parsed = stdout.trim() ? JSON.parse(stdout) : [];
    return Array.isArray(parsed) ? parsed : [parsed];
  }
  const { stdout } = await execFileAsync('ps',['-eo','pid=,comm=,args='], { maxBuffer:32*1024*1024 });
  return stdout.trim().split('\n').map(line => {
    const m = line.trim().match(/^(\d+)\s+(\S+)\s*(.*)$/);
    return m ? { pid:Number(m[1]), name:m[2], command:m[3] } : { raw:line };
  });
}


function assertGuiAllowed(config, state) {
  if (!config.enableGuiAutomation) throw new Error('Computer-use automation is disabled in Commander configuration.');
  const lockPath = path.join(state.baseDir, 'EMERGENCY-LOCK');
  if (fs.existsSync(lockPath) || config.emergencyLock === true) throw new Error('Constellation Commander Emergency Lock is active.');
}

export function createToolHandler({ config, configPath, state, onShutdown }) {
  return async function callTool(name, args = {}) {
    const started = Date.now();
    let ok = true;
    try {
      let result;
      switch (name) {
        case 'list_devices': result = { devices:[{ id:config.deviceName, name:config.deviceName, status:'online', local:true, platform:process.platform }] }; break;
        case 'who_am_i': result = { mode:'self-hosted', deviceName:config.deviceName, accountRequired:false, quotaEnforced:false, quota:null, app:APP_NAME, version:VERSION }; break;
        case 'ping': result = { pong:true, at:now(), deviceName:config.deviceName, app:APP_NAME, version:VERSION }; break;
        case 'get_system_info': result = { app:APP_NAME, version:VERSION, hostname:os.hostname(), platform:process.platform, release:os.release(), arch:process.arch, node:process.version, home:os.homedir(), cwd:process.cwd(), deviceName:config.deviceName }; break;
        case 'get_config': result = redactConfig(config); break;
        case 'set_config_value': {
          const allowed = new Set(['allowedRoots','blockedCommands','enableShell','enableGuiAutomation','localToolMode','telemetryEnabled','defaultShell','deviceName','searchIgnore']);
          if (!allowed.has(args.key)) throw new Error(`Unsupported configuration key: ${args.key}`);
          config[args.key] = args.value;
          await saveConfig(configPath, config);
          result = { updated:args.key, value:args.value };
          break;
        }
        case 'read_file': {
          const p = assertAllowedPath(args.path, config);
          const enc = args.encoding || 'utf8';
          if (enc === 'base64') { const b = await fsp.readFile(p); result = { path:p, encoding:'base64', content:b.toString('base64'), bytes:b.length }; break; }
          const text = await fsp.readFile(p, 'utf8');
          const sliced = linesSlice(text, Number(args.offset || 0), Number(args.length ?? 1000), 0);
          result = { path:p, encoding:'utf8', content:sliced.lines.join('\n'), next_offset:sliced.next, total_lines:text.split(/\r?\n/).length };
          break;
        }
        case 'read_multiple_files': {
          const files = [];
          for (const raw of args.paths || []) {
            try { const p=assertAllowedPath(raw,config); files.push({ path:p, content:await fsp.readFile(p,'utf8') }); }
            catch(e){ files.push({ path:raw, error:String(e.message||e) }); }
          }
          result = { files }; break;
        }
        case 'write_file': {
          const p=assertAllowedPath(args.path,config); await fsp.mkdir(path.dirname(p),{recursive:true});
          const data = (args.encoding || 'utf8') === 'base64' ? Buffer.from(args.content,'base64') : args.content;
          await fsp.writeFile(p,data,{flag:(args.mode||'rewrite')==='append'?'a':'w'}); result={path:p,bytes:Buffer.byteLength(data)}; break;
        }
        case 'edit_block': {
          const p=assertAllowedPath(args.path,config); const text=await fsp.readFile(p,'utf8');
          const parts=text.split(args.old_string); const count=parts.length-1; if(count===0) throw new Error('old_string was not found');
          const expected=args.expected_replacements==null?1:Number(args.expected_replacements); if(count!==expected) throw new Error(`Expected ${expected} replacement(s), found ${count}`);
          const next=parts.join(args.new_string); await fsp.writeFile(p,next); result={path:p,replacements:count}; break;
        }
        case 'write_pdf': { const p=assertAllowedPath(args.path,config); if(path.extname(p).toLowerCase()!=='.pdf') throw new Error('write_pdf path must end in .pdf'); await fsp.mkdir(path.dirname(p),{recursive:true}); const b=simplePdfBuffer(args.content); await fsp.writeFile(p,b); result={path:p,bytes:b.length,pages:'auto'}; break; }
        case 'create_directory': { const p=assertAllowedPath(args.path,config); await fsp.mkdir(p,{recursive:true}); result={path:p}; break; }
        case 'list_directory': { const p=assertAllowedPath(args.path,config); result={root:p,entries:await listDir(p,Math.max(1,Number(args.depth||1)))}; break; }
        case 'get_file_info': { const p=assertAllowedPath(args.path,config); const s=await fsp.stat(p); result={path:p,size:s.size,isFile:s.isFile(),isDirectory:s.isDirectory(),created:s.birthtime.toISOString(),modified:s.mtime.toISOString(),mode:s.mode}; break; }
        case 'copy_file': {
          const s=assertAllowedPath(args.source,config), d=assertAllowedPath(args.destination,config); if(!args.overwrite && fs.existsSync(d)) throw new Error('Destination exists');
          await fsp.cp(s,d,{recursive:true,force:Boolean(args.overwrite),errorOnExist:!args.overwrite}); result={source:s,destination:d}; break;
        }
        case 'move_file': {
          const s=assertAllowedPath(args.source,config), d=assertAllowedPath(args.destination,config); if(!args.overwrite && fs.existsSync(d)) throw new Error('Destination exists');
          if(args.overwrite && fs.existsSync(d)) await fsp.rm(d,{recursive:true,force:true}); await fsp.mkdir(path.dirname(d),{recursive:true}); await fsp.rename(s,d); result={source:s,destination:d}; break;
        }
        case 'trash_path': { const p=assertAllowedPath(args.path,config); await trashPath(p); result={trashed:p}; break; }
        case 'open_path': {
          const target=/^https?:\/\//i.test(args.path)?args.path:assertAllowedPath(args.path,config); await openPath(target); result={opened:target}; break;
        }
        case 'start_search': {
          const root=assertAllowedPath(args.path,config); const sid=id('search'); const resultsPath=path.join(state.baseDir,'searches',`${sid}.jsonl`); await fsp.writeFile(resultsPath,'');
          const job={id:sid,root,query:args.query,mode:args.mode||'both',regex:Boolean(args.regex),caseSensitive:Boolean(args.case_sensitive),resultsPath,status:'running',count:0,startedAt:now(),cancelled:false};
          state.searches.set(sid,job); runSearchJob(job,config); result={search_id:sid,status:'running',root}; break;
        }
        case 'get_more_search_results': {
          const job=state.searches.get(args.search_id); if(!job) throw new Error('Unknown search_id'); const txt=await fsp.readFile(job.resultsPath,'utf8').catch(()=> ''); const rows=txt.trim()?txt.trim().split('\n').map(x=>JSON.parse(x)):[]; const off=Math.max(0,Number(args.offset||0)); const lim=Math.max(1,Number(args.limit||100)); result={search_id:job.id,status:job.status,count:job.count,offset:off,next_offset:Math.min(rows.length,off+lim),results:rows.slice(off,off+lim),error:job.error||null}; break;
        }
        case 'list_searches': result={searches:[...state.searches.values()].map(j=>({id:j.id,root:j.root,query:j.query,status:j.status,count:j.count,startedAt:j.startedAt,finishedAt:j.finishedAt||null}))}; break;
        case 'stop_search': { const job=state.searches.get(args.search_id); if(!job) throw new Error('Unknown search_id'); job.cancelled=true; job.status='cancelling'; result={search_id:job.id,status:job.status}; break; }
        case 'start_process': {
          assertCommandAllowed(args.command,config); const cwd=args.cwd?assertAllowedPath(args.cwd,config):process.cwd(); const spec=shellSpec(args.command,args.shell,config); const sid=id('proc'); const logPath=path.join(state.baseDir,'processes',`${sid}.log`); await fsp.writeFile(logPath,'');
          const child=spawn(spec.exe,spec.args,{cwd,stdio:['pipe','pipe','pipe'],windowsHide:true}); const session={id:sid,command:args.command,cwd,pid:child.pid,child,logPath,status:'running',startedAt:now(),readCursor:0,exitCode:null}; state.processes.set(sid,session);
          const append=chunk=>fsp.appendFile(logPath,chunk).catch(()=>{}); child.stdout.on('data',d=>append(d)); child.stderr.on('data',d=>append(d)); child.on('exit',(code,signal)=>{session.status='finished';session.exitCode=code;session.signal=signal;session.finishedAt=now();});
          const timeout=Number(args.timeout_ms||0); if(timeout>0) setTimeout(()=>{if(session.status==='running'){session.status='timed_out';child.kill();}},timeout).unref(); await sleep(80); result={session_id:sid,pid:child.pid,status:session.status}; break;
        }
        case 'read_process_output': {
          const s=state.processes.get(args.session_id); if(!s) throw new Error('Unknown session_id'); const wait=Math.max(0,Number(args.wait_ms||0)); if(wait) await sleep(Math.min(wait,10000)); const text=await processLines(s); const off=Number(args.offset||0); const slice=linesSlice(text,off,Number(args.length??1000),s.readCursor); if(off===0)s.readCursor=slice.next; result={session_id:s.id,status:s.status,pid:s.pid,exit_code:s.exitCode,output:slice.lines.join('\n'),next_offset:slice.next}; break;
        }
        case 'interact_with_process': {
          const s=state.processes.get(args.session_id); if(!s||s.status!=='running') throw new Error('Session is not running'); s.child.stdin.write(String(args.input)+(String(args.input).endsWith('\n')?'':'\n')); await sleep(Math.min(Math.max(50,Number(args.wait_ms||250)),10000)); const text=await processLines(s); const slice=linesSlice(text,0,1000,s.readCursor); s.readCursor=slice.next; result={session_id:s.id,status:s.status,output:slice.lines.join('\n')}; break;
        }
        case 'list_sessions': result={sessions:[...state.processes.values()].map(s=>({session_id:s.id,pid:s.pid,command:s.command,cwd:s.cwd,status:s.status,startedAt:s.startedAt,finishedAt:s.finishedAt||null,exitCode:s.exitCode}))}; break;
        case 'force_terminate': { const s=state.processes.get(args.session_id); if(!s) throw new Error('Unknown session_id'); if(s.status==='running') { if(process.platform==='win32') await execFileAsync('taskkill',['/PID',String(s.pid),'/T','/F']).catch(()=>{}); else s.child.kill('SIGKILL'); s.status='terminated'; } result={session_id:s.id,status:s.status}; break; }
        case 'list_processes': result={processes:await listSystemProcesses()}; break;
        case 'kill_process': { const pid=Number(args.pid); if(!Number.isInteger(pid)||pid<=0) throw new Error('Invalid pid'); if(process.platform==='win32') await execFileAsync('taskkill',['/PID',String(pid),'/T','/F']); else process.kill(pid,'SIGKILL'); result={pid,terminated:true}; break; }
        case 'computer_displays': { assertGuiAllowed(config,state); result=await computerUse('displays',{}); break; }
        case 'computer_windows': { assertGuiAllowed(config,state); result=await computerUse('windows',args); break; }
        case 'computer_cursor': { assertGuiAllowed(config,state); result=await computerUse('cursor',{}); break; }
        case 'computer_observe': {
          assertGuiAllowed(config,state);
          const displays=await computerUse('displays',{}); const cursor=await computerUse('cursor',{}); const windows=await computerUse('windows',{limit:args.window_limit||120});
          const shot=await computerUse('screenshot',{target:'all',format:'jpeg',max_width:args.max_width||1600,max_height:args.max_height||1200},30000);
          const {base64,mimeType,name:attachmentName,...meta}=shot;
          result={displays:displays.displays,cursor,windows:windows.windows,screenshot:meta,_attachments:[{kind:'screenshot',name:attachmentName,mimeType,base64}]}; break;
        }
        case 'computer_screenshot': {
          assertGuiAllowed(config,state); const shot=await computerUse('screenshot',args,30000); const {base64,mimeType,name:attachmentName,...meta}=shot;
          result={...meta,_attachments:[{kind:'screenshot',name:attachmentName,mimeType,base64}]}; break;
        }
        case 'computer_move_mouse': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'move',x:args.x,y:args.y}]}); break; }
        case 'computer_click': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'click',x:args.x,y:args.y,button:args.button||'left'}]}); break; }
        case 'computer_double_click': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'double_click',x:args.x,y:args.y,button:args.button||'left'}]}); break; }
        case 'computer_drag': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'drag',from_x:args.from_x,from_y:args.from_y,to_x:args.to_x,to_y:args.to_y,steps:args.steps}]}); break; }
        case 'computer_scroll': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'scroll',amount:args.amount,horizontal:Boolean(args.horizontal)}]}); break; }
        case 'computer_keypress': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'keypress',key:args.key,repeat:args.repeat}]}); break; }
        case 'computer_hotkey': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'hotkey',keys:args.keys}]}); break; }
        case 'computer_type': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'type',text:args.text,settle_ms:args.settle_ms}]}); break; }
        case 'computer_wait': { assertGuiAllowed(config,state); result=await computerUse('actions',{actions:[{type:'wait',ms:args.ms??500}]},Math.max(5000,Number(args.ms||500)+3000)); break; }
        case 'computer_actions': {
          assertGuiAllowed(config,state); const actionResult=await computerUse('actions',{actions:args.actions||[]},30000); result={...actionResult};
          if(args.screenshot_after!==false){ const shot=await computerUse('screenshot',args.screenshot||{},30000); const {base64,mimeType,name:attachmentName,...meta}=shot; result.screenshot=meta; result._attachments=[{kind:'screenshot',name:attachmentName,mimeType,base64}]; }
          break;
        }
        case 'computer_focus_window': { assertGuiAllowed(config,state); result=await computerUse('focus_window',args); break; }
        case 'computer_window_state': { assertGuiAllowed(config,state); result=await computerUse('window_state',args); break; }
        case 'computer_close_window': { assertGuiAllowed(config,state); result=await computerUse('close_window',args); break; }
        case 'computer_clipboard_read': { assertGuiAllowed(config,state); result=await computerUse('clipboard_read',{}); break; }
        case 'computer_clipboard_write': { assertGuiAllowed(config,state); result=await computerUse('clipboard_write',args); break; }
        case 'computer_click_ui_element': {
          assertGuiAllowed(config,state); const ui=await computerUse('ui_elements',{...args,max_results:1},30000); const element=ui.elements?.[0]; if(!element) throw new Error('No matching UI element was found.');
          if(element.width<=0||element.height<=0||element.offscreen) throw new Error('Matching UI element is not currently clickable on screen.');
          await computerUse('actions',{actions:[{type:'click',x:Math.round(element.x+element.width/2),y:Math.round(element.y+element.height/2),button:'left'}]});
          result={clicked:true,element};
          if(args.screenshot_after!==false){ const shot=await computerUse('screenshot',{},30000); const {base64,mimeType,name:attachmentName,...meta}=shot; result.screenshot=meta; result._attachments=[{kind:'screenshot',name:attachmentName,mimeType,base64}]; }
          break;
        }
        case 'computer_find_ui_elements': { assertGuiAllowed(config,state); result=await computerUse('ui_elements',args,30000); break; }
        case 'get_recent_tool_calls': {
          const max=Math.min(1000,Math.max(1,Number(args.max_results||50))); let text=''; try{text=await fsp.readFile(state.callsPath,'utf8');}catch{} const rows=text.trim()?text.trim().split('\n').slice(-max).map(x=>JSON.parse(x)):[]; result={calls:rows}; break;
        }
        case 'get_usage_stats': {
          let stats={totalCalls:0,byTool:{},errors:0}; try{stats=JSON.parse(await fsp.readFile(state.statsPath,'utf8'));}catch{} result={...stats,quotaEnforced:false,quota:null,message:'Local counters only; Constellation Commander does not impose a tool-call quota.'}; break;
        }
        case 'shutdown': { result={shutting_down:true}; void closeComputerUseHelper(); setTimeout(()=>onShutdown?.(),100).unref(); break; }
        default: throw new Error(`Unknown tool: ${name}`);
      }
      await recordCall(state,{tool:name,ok:true,durationMs:Date.now()-started,argsSummary:Object.keys(args||{})});
      return result;
    } catch (e) {
      ok=false; await recordCall(state,{tool:name,ok:false,durationMs:Date.now()-started,error:String(e.message||e),argsSummary:Object.keys(args||{})}); throw e;
    }
  };
}
