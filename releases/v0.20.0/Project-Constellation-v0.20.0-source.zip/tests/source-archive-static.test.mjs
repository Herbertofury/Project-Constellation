import assert from 'node:assert/strict';
import fs from 'node:fs';

const sourceArchive=fs.readFileSync(new URL('../tools/source-archive.mjs',import.meta.url),'utf8');
const packager=fs.readFileSync(new URL('../tools/package-unified-release.mjs',import.meta.url),'utf8');
assert.match(sourceArchive,/git', \['ls-tree', '-r', '-z'/);
assert.match(sourceArchive,/git', \['cat-file', 'blob'/);
assert.match(sourceArchive,/Unsupported git file mode/);
assert.match(sourceArchive,/zip', \['-X', '-q', target, '-@'/);
assert.match(sourceArchive,/export function writeDirectoryFilesZip/);
assert.match(sourceArchive,/tar\.exe', \['-a', '-c', '-f', target, '-T', '-'/);
assert.match(packager,/writeExactGitSourceZip/);
assert.match(packager,/writeDirectoryFilesZip/);
assert.doesNotMatch(packager,/Compress-Archive/);
assert.doesNotMatch(packager,/\['-X','-q','-r'/);
assert.doesNotMatch(packager,/git',\['archive'/);
console.log('source archive static: PASS');
