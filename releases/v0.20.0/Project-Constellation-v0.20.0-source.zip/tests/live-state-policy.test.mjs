import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source = fs.readFileSync(new URL('../extension/background.js', import.meta.url), 'utf8');
function functionSource(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `${name} exists`);
  let parens = 0;
  let brace = -1;
  for (let i = source.indexOf('(', start); i < source.length; i += 1) {
    if (source[i] === '(') parens += 1;
    else if (source[i] === ')') parens -= 1;
    else if (source[i] === '{' && parens === 0) { brace = i; break; }
  }
  assert.ok(brace >= 0, `${name} body exists`);
  let depth = 0;
  for (let i = brace; i < source.length; i += 1) {
    if (source[i] === '{') depth += 1;
    else if (source[i] === '}') {
      depth -= 1;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }
  throw new Error(`Could not extract ${name}`);
}

const bucketSource = functionSource('livePulseBucket');
const sandbox = {
  LIVE_CRITICAL_STATUSES:new Set(['blocked-approval','delivery-timeout','connection-interrupted','response-interrupted','send-failed','refresh-required']),
  LIVE_HOLD_STATUSES:new Set(['provider-review']),
  LIVE_CRITICAL_HEALTH_STATES:new Set(['delivery-timeout','connection-interrupted','response-interrupted','send-failed','refresh-required','blocked-approval','dead','tool-dead','capacity-reached','degraded','stale-page']),
  LIVE_HOLD_HEALTH_STATES:new Set(['provider-review']),
  LIVE_STALE_STATUSES:new Set(['paused','waiting-user','rate-limited','errored','stalled','auth-required','unavailable']),
  LIVE_STALE_HEALTH_STATES:new Set(['rate-limited','auth-required','unavailable','stalled','request-stalled','tool-stalled','capacity-watch','capacity-handoff']),
  LIVE_ACTIVE_HEALTH_STATES:new Set(['working','tool-running','tool-quiet','quiet-working'])
};
vm.createContext(sandbox);
vm.runInContext(`${bucketSource}; globalThis.__bucket=livePulseBucket;`, sandbox);
assert.equal(sandbox.__bucket({chat:{status:'idle',healthState:'healthy'},generation:{active:false}}, {pending:9,streamLikely:true}), 'completed', 'background provider traffic cannot resurrect a completed chat');
assert.equal(sandbox.__bucket({chat:{status:'running',healthState:'working'},generation:{active:true}}, {pending:0}), 'active');
assert.equal(sandbox.__bucket({chat:{status:'provider-review',healthState:'provider-review'},generation:{active:false}}, {pending:2}), 'hold', 'provider review is a dedicated On Hold state, not a stall');
assert.equal(sandbox.__bucket({chat:{status:'rate-limited',healthState:'rate-limited'}}, {pending:4}), 'stale');
assert.equal(sandbox.__bucket({chat:{status:'delivery-timeout',healthState:'delivery-timeout'},failure:{active:true,retryAvailable:true}}, {pending:4}), 'critical', 'explicit provider delivery failure becomes Critical even with pending network');
assert.equal(sandbox.__bucket({chat:{status:'idle',healthState:'capacity-reached'}}, {pending:0}), 'critical', 'conversation maximum/capacity reached is Critical');
assert.equal(sandbox.__bucket({chat:{status:'running',healthState:'capacity-handoff'}}, {pending:0}), 'stale', 'proactive handoff remains Needs Attention until the hard limit is reached');

const normalizePulseSource = functionSource('normalizePulseUx');
const pulseSandbox = {
  TAB_BEACON_DEFAULTS:{completionNotificationsEnabled:true,criticalNotificationsEnabled:true,reviewReleaseNotificationsEnabled:true,attentionNotificationsEnabled:true,branchReviewBeforeSend:true,tabBeaconsEnabled:true,tabTitleStatusEnabled:true,tabFaviconStatusEnabled:true,tabGroupingEnabled:true,tabGroupingMode:'project-status',criticalEmoji:'🔴',holdEmoji:'🛡️',activeEmoji:'🟣',staleEmoji:'⚠️',completedEmoji:'✅',criticalColor:'#ff5c64',holdColor:'#4fa3ff',activeColor:'#8b5cf6',staleColor:'#e0a458',completedColor:'#45bd8c',criticalGroupColor:'red',holdGroupColor:'blue',activeGroupColor:'purple',staleGroupColor:'orange',completedGroupColor:'green'},
  NATIVE_GROUP_COLORS:new Set(['grey','blue','red','yellow','green','pink','purple','cyan','orange']),
  normalizeHexColor:(value,fallback)=>/^#[0-9a-f]{6}$/i.test(String(value||''))?String(value):fallback
};
vm.createContext(pulseSandbox); vm.runInContext(`${normalizePulseSource}; globalThis.__normalizePulseUx=normalizePulseUx;`, pulseSandbox);
assert.equal(pulseSandbox.__normalizePulseUx({holdEmoji:'🔵'}).holdEmoji, '🛡️', 'legacy default blue-circle hold marker migrates to shield');
assert.equal(pulseSandbox.__normalizePulseUx({holdEmoji:'🧿'}).holdEmoji, '🧿', 'non-default custom hold marker remains user-owned');

const managedGroupSource = functionSource('managedGroupBucket');
const groupSandbox = { TAB_GROUP_PREFIX:'PC ✦' }; vm.createContext(groupSandbox); vm.runInContext(`${managedGroupSource}; globalThis.__groupBucket=managedGroupBucket;`, groupSandbox);
assert.equal(groupSandbox.__groupBucket('My Research'), '', 'user-created tab group is never treated as Constellation-owned');
assert.equal(groupSandbox.__groupBucket('PC ✦ 🔴 Critical'), 'critical');
assert.equal(groupSandbox.__groupBucket('PC ✦ 🛡️ On hold'), 'hold');
assert.equal(groupSandbox.__groupBucket('PC ✦ 🟣 Active'), 'active');
assert.equal(groupSandbox.__groupBucket('PC ✦ ⚠️ Needs attention'), 'stale');
assert.equal(groupSandbox.__groupBucket('PC ✦ ✅ Completed'), 'completed');
assert.match(source, /message\?\.state\?\.sentinel !== true \|\| message\?\.state\?\.source !== 'live-sentinel'/, 'legacy content pushes are rejected');
assert.match(source, /String\(message\?\.state\?\.version \|\| ''\) !== LIVE_SENTINEL_VERSION/, 'pre-upgrade Sentinel pushes are rejected before they can regress a tab group');
assert.match(source, /existing\?\.version === LIVE_SENTINEL_VERSION/, 'hot upgrades replace stale Sentinel versions');
assert.match(source, /files:\[HEALTH_CORE_FILE, LIVE_SENTINEL_FILE\]/, 'hot upgrades inject the current health core with the Sentinel so existing tabs gain Runway Sentinel without refresh');
const contentSource = fs.readFileSync(new URL('../extension/src/content.js', import.meta.url), 'utf8');
function functionSourceFrom(text, name) {
  const start = text.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `${name} exists`);
  let parens = 0, brace = -1;
  for (let i = text.indexOf('(', start); i < text.length; i += 1) {
    if (text[i] === '(') parens += 1; else if (text[i] === ')') parens -= 1; else if (text[i] === '{' && parens === 0) { brace = i; break; }
  }
  let depth = 0;
  for (let i = brace; i < text.length; i += 1) {
    if (text[i] === '{') depth += 1; else if (text[i] === '}') { depth -= 1; if (depth === 0) return text.slice(start, i + 1); }
  }
  throw new Error(`Could not extract ${name}`);
}
const scheduleStart = contentSource.indexOf('function scheduleLiveHealthPulse');
const scheduleEnd = contentSource.indexOf('const ACTIVE_TOOL_LABEL_PATTERN', scheduleStart);
const scheduleSource = contentSource.slice(scheduleStart, scheduleEnd);
assert.doesNotMatch(scheduleSource, /outputCompareSummary\?\.active|output-regressed/, 'Output Vault warnings stay out of the primary active polling lane');
const reconcileSource = functionSourceFrom(contentSource, 'reconcileHealthSnapshotWithSentinel');
const reconcileSandbox = {
  brain:{normalizeText:(value,max=150)=>String(value||'').slice(0,max)},
  liveSentinelState:()=>reconcileSandbox.__sentinel,
  __sentinel:{ok:true,source:'live-sentinel',chat:{status:'running',healthState:'tool-stalled'},health:{state:'tool-stalled',level:'danger',title:'Tool call looks stuck',detail:'No meaningful progress'},generation:{phase:'thinking',quietForMs:130000},tool:{present:true,active:true,busy:true,label:'Running tool',phase:'executing',lastProgressAt:Date.now()-130000,entryCount:2}}
};
vm.createContext(reconcileSandbox);
vm.runInContext(`${reconcileSource}; globalThis.__reconcile=reconcileHealthSnapshotWithSentinel;`, reconcileSandbox);
let reconciled = reconcileSandbox.__reconcile({state:'tool-stalled',level:'danger',title:'Tool call looks stuck',detail:'No meaningful progress',capacity:{state:'clear'},activity:null});
assert.equal(reconciled.state,'tool-stalled','Sentinel preserves a watchdog stall while its own current health still agrees');
assert.equal(reconciled.level,'danger');
reconcileSandbox.__sentinel={ok:true,source:'live-sentinel',chat:{status:'running',healthState:'tool-running'},health:{state:'tool-running',level:'active',title:'Tool working',detail:'Recent progress'},generation:{phase:'inspecting',quietForMs:8000},tool:{present:true,active:true,busy:true,label:'Inspecting ModForge source and report formats',phase:'inspecting',lastProgressAt:Date.now()-8000,entryCount:5}};
reconciled = reconcileSandbox.__reconcile({state:'tool-stalled',level:'danger',title:'Tool call looks stuck',detail:'Old content-loop warning',capacity:{state:'clear'},activity:null});
assert.equal(reconciled.state,'tool-running','fresh Sentinel progress clears an older content-loop stall instead of pinning Needs Attention');
assert.equal(reconciled.level,'active');
reconciled = reconcileSandbox.__reconcile({state:'working',level:'danger',title:'Chat is working',detail:'',capacity:{state:'handoff',level:'danger',title:'Secure a handoff now',detail:'Runway narrow',recommendedAction:'handoff'},activity:null});
assert.equal(reconciled.state,'capacity-handoff','capacity danger remains primary during active generation');
assert.equal(reconciled.title,'Secure a handoff now');
reconcileSandbox.__sentinel={ok:true,source:'live-sentinel',chat:{status:'idle',healthState:'healthy'},health:{state:'healthy',level:'healthy'},generation:{},tool:{}};
reconciled = reconcileSandbox.__reconcile({state:'capacity-watch',level:'warning',title:'Conversation runway narrowing',detail:'',capacity:{state:'watch',level:'warning'},activity:null});
assert.equal(reconciled.state,'capacity-watch','Sentinel idle cannot hide a capacity warning');
const sentinelSource = fs.readFileSync(new URL('../extension/src/live-sentinel.js', import.meta.url), 'utf8');
const transcriptProbeSource = fs.readFileSync(new URL('../extension/src/chatgpt-page-probe.js', import.meta.url), 'utf8');
const tabBeaconSource = fs.readFileSync(new URL('../extension/src/tab-beacon.js', import.meta.url), 'utf8');
assert.match(sentinelSource, /const rawActive = failure\.active \|\| reviewHold\.active \? false : transcriptFinal \? false : transcriptRunning \? true : domActive/, 'fresh transcript finality outranks stale DOM while unfinished transcript outranks settled DOM');
assert.match(sentinelSource, /classifyProviderHold/, 'Sentinel detects the explicit ChatGPT review-hold surface');
assert.match(sentinelSource, /provider-review-surface/, 'Sentinel publishes provider review as its own source');
assert.match(sentinelSource, /PC_LIVE_SENTINEL_REFRESH_TRANSCRIPT/, 'authoritative transport completion can request an event-driven transcript refresh');
assert.doesNotMatch(sentinelSource, /if \(state\.running\) \{ lastActivityAt = now\(\); lastProgressAt = now\(\); \}/, 'transcript polling alone never refreshes the progress clock');
assert.match(sentinelSource, /return state\.startsWith\('capacity-'\) \? state : ''/, 'Sentinel never reads its own rendered stall state back as a watchdog heartbeat');
assert.match(sentinelSource, /if \(authoritativeWatchdog\) return;/, 'current-version HUD has one renderer owner so Sentinel cannot race the content HUD clocks');
assert.match(sentinelSource, /project-constellation:live-sentinel-state/, 'Sentinel publishes a sanitized state-transition event for the single content HUD owner');
assert.match(contentSource, /const LIVE_SENTINEL_STATE_EVENT = 'project-constellation:live-sentinel-state'/, 'content subscribes to the Sentinel transition channel');
assert.match(contentSource, /scheduleLiveHealthPulse\(70, true\)/, 'content urgently converges the single HUD renderer after a Sentinel transition');
assert.match(sentinelSource, /persistent spinner\/active label is proof[\s\S]{0,260}Only a changed current-tool signature resets/, 'unchanged tool spinners are not treated as forward progress');
assert.match(contentSource, /storedChars[\s\S]{0,500}transcriptTurns[\s\S]{0,500}transcriptChars/, 'capacity evidence combines persistent storage with full transcript measurements');
assert.match(source, /authoritativeTransport[\s\S]{0,500}PC_LIVE_SENTINEL_REFRESH_TRANSCRIPT/, 'background requests transcript refresh after authoritative ChatGPT transport settles');
assert.match(sentinelSource, /button\[data-testid="copy-turn-action-button"\]/, 'current ChatGPT completion control uses the precise production testid');
assert.match(sentinelSource, /currentAssistantBusy/, 'aria-busy is scoped to the current assistant turn rather than page layout ancestors');
for (const marker of ['/backend-api/conversation/','finished_successfully','end_turn','chatgpt_sdk.widget_state']) assert.ok(transcriptProbeSource.includes(marker), `transcript probe includes ${marker}`);
assert.match(source, /if \(!currentManagedBucket\) return \{ ok:true, skipped:'user-group' \}; \/\/ User-created groups stay exactly where the user put them\./, 'automatic status grouping preserves user-created tab groups');
assert.match(source, /tabGroupSyncQueue = tabGroupSyncQueue\.catch/, 'Constellation-owned group moves are serialized to avoid duplicate status groups');
assert.match(source, /if \(ok\) tabPresentationSignatures\.set\(tabId, signature\)/, 'presentation signature is committed only after Chrome confirms reconciliation');
assert.match(source, /scheduleTabPresentationRepair\(tabId\)/, 'failed presentation/group reconciliation schedules a bounded self-heal');
assert.match(source, /row\?\.tabGroup\?\.managed && row\.tabGroup\.managedBucket !== row\.bucket/, 'Pulse performs a managed-group convergence audit without touching user groups');
assert.match(source, /fallbackLiveRow[\s\S]{0,1200}status:'unavailable'[\s\S]{0,300}bucket:'stale'/, 'unresponsive open chat tabs remain represented instead of disappearing from Pulse counts');
assert.match(source, /let state = await readLiveSentinelState\(tabId\);[\s\S]{0,450}ensureChatGPTPageProbe/, 'Pulse reads the installed Sentinel before doing expensive MAIN-world reinjection checks');
for (const marker of ['chrome.tabs.group','chrome.tabGroups.update','PC_TAB_TAG_SET','renderActionBadge']) assert.ok(source.includes(marker), `tab presentation backend includes ${marker}`);
for (const marker of ['PC_TAB_BEACON_APPLY','faviconDataUri','baseTitle']) assert.ok(tabBeaconSource.includes(marker), `tab beacon content includes ${marker}`);
console.log('live-state-policy.test.mjs: PASS');
