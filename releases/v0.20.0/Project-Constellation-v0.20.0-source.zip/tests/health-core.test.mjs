import assert from 'node:assert/strict';
await import('../extension/src/health-core.js');
const core = globalThis.ProjectConstellationHealthCore;
assert(core);
const now = 1_000_000;
let row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-1000, network:{pending:1,oldestPendingAt:now-3000,lastStartAt:now-3000,lastResponseAt:now-500}, tool:{present:true,active:true,label:'Searching project files',phase:'searching',lastProgressAt:now-700,entryCount:4} });
assert.equal(row.state,'tool-running');
assert.equal(row.networkActive,true);
assert.match(row.title,/Tool working/i);
assert.equal(row.activity.kind,'tool');
assert.equal(row.activity.entryCount,4);
assert.equal(row.proof.evidenceOnly,true);
assert.equal(row.proof.certainty,'high');
assert.equal(row.proof.verdict,'active');
assert.deepEqual(new Set(row.proof.sources.map((item)=>item.kind)),new Set(['network','tool','response','status']));

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-180000, network:{pending:1,oldestPendingAt:now-175000,lastStartAt:now-175000,lastResponseAt:now-175000}, tool:{present:true,active:true,label:'Called tool',phase:'tool call',lastProgressAt:now-180000,entryCount:9}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'tool-stalled');
assert.equal(row.level,'danger');
assert.match(row.detail,/still open/i);

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-300000, network:{pending:1,oldestPendingAt:now-300000,lastStartAt:now-300000,lastResponseAt:now-300000}, tool:{present:true,active:true,label:'Called tool',phase:'tool call',lastProgressAt:now-300000,entryCount:12}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'tool-dead');
assert.equal(row.level,'critical');
assert.match(row.title,/appears dead/i);

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-260000, network:{pending:0,lastCompleteAt:now-270000}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'uncertain-working', 'a stale running label alone must never create a false dead-chat alarm');
assert.equal(row.proof.verdict,'uncertain');
assert.equal(row.recommendedAction,'');

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-180000, network:{pending:0,lastCompleteAt:now-180000}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'uncertain-working', 'a stale running label alone must never create a false stall alarm');

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-180000, provider:{status:'in_progress',observedAt:now-1000,currentTurnOwned:true}, tool:{present:true,active:true,label:'Deep research',lastProgressAt:now-180000}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'tool-running', 'fresh provider transcript heartbeat outranks a stale visible tool card');
assert.equal(row.proof.verdict,'active');
assert(row.proof.sources.some((item)=>item.kind==='provider' && item.active));

row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-180000, runtime:{currentTurnOwned:true,requestActive:true,stopControl:true}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state,'stalled', 'a stall still requires corroborated current-turn activity, not just status text');

row = core.deriveHealth({ now, chatStatus:'idle', page:{catalogAhead:true} });
assert.equal(row.state,'stale-page');
assert.equal(row.recommendedAction,'refresh');
assert(row.proof.sources.some((item)=>item.kind==='page'));
row = core.deriveHealth({ now, chatStatus:'idle', page:{outputRegression:{active:true,detail:'1 missing response · 2 media items'}} });
assert.equal(row.state,'output-regressed');
assert.equal(row.level,'critical');
assert.equal(row.recommendedAction,'compare-output');
assert.match(row.detail,/missing response/i);
row = core.deriveHealth({ now, chatStatus:'refresh-required', network:{pending:0} });
assert.equal(row.state,'refresh-required');
assert.equal(row.recommendedAction,'refresh');
row = core.deriveHealth({ now, chatStatus:'idle', integrityFindings:[{type:'old-version-chat',detail:'v0.9 behind v0.10'}], baselineVersion:'0.10.0' });
assert.equal(row.state,'old-project-version');
assert.equal(row.projectRisk,true);
row = core.deriveHealth({ now, chatStatus:'idle', integrityFindings:[{type:'project-version-rollback',detail:'rollback'}] });
assert.equal(row.state,'project-rollback');
assert.equal(row.level,'critical');

let capacity = core.deriveCapacity({ storedTurns: 179, capturedChars: 100000 }, { capacityWarningTurns: 180, capacityHandoffTurns: 260 });
assert.equal(capacity.state, 'clear');
capacity = core.deriveCapacity({ storedTurns: 180, capturedChars: 100000 }, { capacityWarningTurns: 180, capacityHandoffTurns: 260 });
assert.equal(capacity.state, 'watch');
assert.equal(capacity.recommendedAction, 'handoff');
capacity = core.deriveCapacity({ storedTurns: 260, capturedChars: 100000 }, { capacityWarningTurns: 180, capacityHandoffTurns: 260 });
assert.equal(capacity.state, 'handoff');
assert.equal(capacity.level, 'danger');
capacity = core.deriveCapacity({ storedTurns: 40, explicitLimitSignal: true, explicitLimitText: 'Maximum conversation length reached' });
assert.equal(capacity.state, 'reached');
assert.equal(capacity.level, 'critical');
capacity = core.deriveCapacity({ storedTurns: 40, explicitLimitSignal: true, explicitLimitText: "You've reached the maximum length for this conversation, but you can keep talking by starting a new chat." });
assert.equal(capacity.state, 'reached', 'exact ChatGPT hard-stop banner must be critical capacity, not a generic page error');
assert.match(capacity.title, /maximum reached/i);
capacity = core.deriveCapacity({ storedTurns: 40, nearLimitSignal: true, nearLimitText: 'This conversation is approaching the maximum length. Consider starting a new chat soon.' });
assert.equal(capacity.state, 'handoff', 'provider near-limit copy must jump straight to secure handoff');
capacity = core.deriveCapacity({ transcriptTurns:70, activeBranchMessages:120, structuredMessages:50, toolMessages:30, transcriptChars:90000 });
assert.equal(capacity.state, 'watch', 'tool/app branch pressure warns even when visible message count and text are modest');
assert.equal(capacity.adaptiveWatch, true);
assert.equal(capacity.activeBranchMessages, 120);
assert.equal(capacity.structuredMessages, 50);
capacity = core.deriveCapacity({ transcriptTurns:85, activeBranchMessages:155, structuredMessages:70, toolMessages:52, transcriptChars:105000 });
assert.equal(capacity.state, 'handoff', 'heavy structured/tool branch pressure escalates before the provider hard stop');
assert.equal(capacity.adaptiveHandoff, true);
capacity = core.deriveCapacity({ storedTurns: 24, storedChars: 250000 }, { capacityWarningTurns:180,capacityHandoffTurns:260,capacityWarningChars:240000,capacityHandoffChars:400000 });
assert.equal(capacity.state, 'watch', 'persisted characters warn even after a content-script reload');
assert.equal(capacity.capturedChars, 250000);
capacity = core.deriveCapacity({ storedTurns: 12, mountedTurns: 6, transcriptTurns: 265, transcriptChars: 310000 }, { capacityWarningTurns:180,capacityHandoffTurns:260,capacityWarningChars:240000,capacityHandoffChars:400000 });
assert.equal(capacity.state, 'handoff', 'full active-branch transcript outranks the small mounted DOM');
assert.equal(capacity.turnCount, 265);
assert.equal(capacity.transcriptChars, 310000);
capacity = core.deriveCapacity({ storedTurns: 70, storedChars: 190000, recentAverageChars: 75000 }, { capacityWarningTurns:180,capacityHandoffTurns:260,capacityWarningChars:240000,capacityHandoffChars:400000 });
assert.equal(capacity.state, 'watch', 'very large recent turns trigger predictive runway warning');
assert.equal(capacity.predictiveWatch, true);
assert(capacity.projectedMessages < 3);
row = core.deriveHealth({ now, chatStatus:'idle', capacity:{storedTurns:180}, settings:{capacityWarningTurns:180,capacityHandoffTurns:260} });
assert.equal(row.state,'capacity-watch');
assert.equal(row.capacity.state,'watch');
row = core.deriveHealth({ now, chatStatus:'running', lastTurnProgressAt:now-1000, capacity:{storedTurns:260}, settings:{capacityWarningTurns:180,capacityHandoffTurns:260} });
assert.equal(row.state,'working');
assert.equal(row.level,'danger');
assert.equal(row.capacity.recommendedAction,'handoff');
row = core.deriveHealth({ now, chatStatus:'refresh-required', capacity:{storedTurns:260}, settings:{capacityWarningTurns:180,capacityHandoffTurns:260} });
assert.equal(row.state,'refresh-required');
assert.equal(row.recommendedAction,'refresh');
assert.equal(row.capacity.recommendedAction,'handoff');


const holdBanner = 'Our systems are thinking a bit more about this request before responding. You can retry with a faster model for a quick response, though it may be less capable of handling complex requests. Learn more';
const hold = core.classifyProviderHold(holdBanner);
assert.equal(hold.active, true);
assert.equal(hold.state, 'provider-review');
assert.match(hold.title, /On hold/i);
row = core.deriveHealth({ now, chatStatus:'provider-review', lastTurnProgressAt:now-180000, network:{pending:0}, settings:{softStallMs:30000,hardStallMs:90000,deadStallMs:240000} });
assert.equal(row.state, 'provider-review', 'provider review hold must not be misclassified as a stall');
assert.equal(row.level, 'info');
assert.equal(row.recommendedAction, '');
assert.equal(core.classifyProviderHold('The model is thinking about this request.').active, false, 'ordinary thinking copy is not a review hold');

for (const [text, state, title] of [
  ['Message delivery timed out. Please try again.','delivery-timeout','Message delivery timed out'],
  ['A network error occurred. Please check your connection and try again.','connection-interrupted','Connection interrupted'],
  ['There was an error generating a response.','response-interrupted','Response interrupted'],
  ['Message was not sent.','send-failed','Message was not sent']
]) {
  const failure = core.classifyProviderFailure(text, { retryAvailable:true, retryLabel:'Retry', partialAssistantChars:45, toolActivitySeen:true });
  assert.equal(failure.active, true); assert.equal(failure.state, state); assert.equal(failure.retryAvailable, true);
  const failureRow = core.deriveHealth({ now, chatStatus:'running', running:true, lastTurnProgressAt:now-500, failure, capacity:{storedTurns:260}, settings:{capacityWarningTurns:180,capacityHandoffTurns:260} });
  assert.equal(failureRow.state, state, `${state} must outrank stale running/capacity evidence`);
  assert.equal(failureRow.level, 'critical'); assert.equal(failureRow.title, title); assert.equal(failureRow.recommendedAction, 'retry');
  assert.ok(failureRow.chips.includes('45 partial chars preserved'));
}
const noRetryFailure = core.classifyProviderFailure('Message delivery timed out. Please try again.', {});
assert.equal(noRetryFailure.recommendedAction, 'refresh');
assert.equal(core.deriveHealth({ now, chatStatus:'delivery-timeout', failure:noRetryFailure }).state, 'delivery-timeout');

const hardCapacityText = "You've reached the maximum length for this conversation, but you can keep talking by starting a new chat.";
const hardCapacitySignal = core.classifyProviderCapacity(hardCapacityText);
assert.equal(hardCapacitySignal.state, 'reached');
assert.equal(hardCapacitySignal.explicitLimitSignal, true);
assert.match(hardCapacitySignal.explicitLimitText, /maximum length/i);
const hardCapacityRow = core.deriveHealth({
  now, chatStatus:'running', running:true, lastTurnProgressAt:now-500,
  network:{pending:1,oldestPendingAt:now-900,lastStartAt:now-900,lastResponseAt:now-200},
  capacity:{storedTurns:40, ...hardCapacitySignal}
});
assert.equal(hardCapacityRow.state, 'capacity-reached', 'an explicit provider maximum must outrank stale running/network evidence');
assert.equal(hardCapacityRow.level, 'critical');
assert.equal(hardCapacityRow.recommendedAction, 'handoff');

console.log('health-core.test.mjs: PASS');
