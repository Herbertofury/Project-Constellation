# ChatGPT.com compatibility

Project Constellation treats ChatGPT’s web UI as a changing provider surface, not a stable internal API.

## Current verified contracts

Live compatibility was checked against `https://chatgpt.com/` on 2026-08-24. Current conversation turns use `data-testid="conversation-turn-N"` containers with nested `data-message-author-role` and `data-message-id`. The composer exposes a visible contenteditable element with role `textbox` and accessible name **Chat with ChatGPT**; the similarly named textarea can be hidden. Streaming exposes a visible **Stop answering** control and/or busy/streaming attributes.

Current agent activity uses legacy generic `group/tool-message` rows alongside concise step summaries styled with tertiary text classes; the active summary uses `loading-shimmer-tertiary`. Constellation prefers the active concise summary (for example, an observable “Inspecting…” or “Implementing…” label), deduplicates nested copies, and keeps generic `Called tool` rows only as bounded step-count evidence.

The selector strategy prefers top-level conversation-turn containers, then falls back to role/message IDs. This prevents duplicate capture from nested current markup. Root-path anonymous conversations receive an in-tab session ID so they are not mistaken for the empty Home screen.

## What Constellation observes

- chat links and route changes;
- rendered user/assistant turn containers plus structured text, links, code, images, video, audio, documents, and generated-output metadata;
- attachment/download/link evidence;
- visible status, approval, delivery failure, rate-limit, auth, and unavailable surfaces;
- visible agent/tool step summaries, tool-state evidence, and sanitized passive request lifecycle from the service worker;
- a bounded local activity ledger for response DOM changes, page status, tool progress, handoff/recovery, and request start/response/completion.
- a hydrated, bottom-of-conversation output-tail fingerprint used to detect missing or meaningfully shortened assistant revisions after a refresh.

The content script makes no network calls, does not patch ChatGPT JavaScript, does not remove messages, and does not depend on undocumented ChatGPT backend APIs. It cannot see private chain-of-thought and never pretends otherwise. Request URLs and prompt content are not placed in the HUD ledger; only a sanitized category, lifecycle phase, method/status, and duration are exposed. History/sidebar/session traffic is auxiliary and cannot prove that the model is alive.

The Pulse's **Branch & continue** control uses only an explicit user click, the normal ChatGPT new-chat route, and the visible native composer. It waits for the usable composer/send control, dispatches native input events, confirms a send from observable composer/route changes, and then links the resulting chat ID to the source checkpoint. It does not call a hidden conversation API, overwrite existing draft text, or claim success from a click alone.

The Pulse's permanent **⇄ Output Vault** control reads only Constellation's captured IndexedDB state. The service worker keeps each distinct turn revision and prevents a lower-richness assistant observation from replacing the richest canonical output. During changed-turn ingestion, the content runtime also serializes the mounted semantic answer container into bounded Markdown so Reader mode can reproduce ChatGPT-like headings, emphasis, lists, quotes, tables, code, and links without storing executable HTML. Comparison is suppressed during streaming, before hydration, and while browsing away from the bottom. Vault and Pulse use coordinated isolated shadow DOMs, share a measured collision-free dock, and never insert recovered content into ChatGPT's conversation tree. Remote media preview is user-triggered so simply opening the vault creates no ChatGPT or media traffic.

## Approval and recovery

Approval Recovery recognizes both accessible dialogs and the current ordinary inline provider card (for example, **Allow ChatGPT to use GitHub?**). A narrow approval-only observer reacts when a usable prompt mounts, including in a background tab, without keeping the broad capture observer active. It finds ChatGPT's split **Allow ▾** control by semantics, DOM proximity, and geometry; opens its portalled menu; prefers the provider-specific **Allow [provider] for this conversation** option (plus equivalent Always allow/Never ask variants); and falls back to the main Allow action only when the saved setting permits it.

Always-allow behavior remains off until the user explicitly acknowledges its risk. A click is not treated as success: the approval card must visibly disappear, otherwise the attempt is reported as failed and retried with a bounded backoff. Open ChatGPT tabs react immediately, and the existing single-window recovery sweep revisits known blocked/stale chats. Delivery failures request a controlled browser refresh; Constellation never loops on ChatGPT’s Retry button. Rate-limit signals enter the provider request governor and stop Constellation-originated background work during cooldown.

## Maintaining compatibility

When ChatGPT changes:

1. Reproduce on the live site without inspecting cookies, session storage, passwords, or private profile data.
2. Capture accessibility and non-sensitive DOM attribute evidence.
3. Update provider-specific selectors with semantic fallbacks.
4. Add a minimized current-DOM fixture under `tests/smoke/`.
5. Verify exactly-once turns, composer preservation, status/tool behavior, no content-script fetch, and bounded message counts.
6. Run the complete suite and update the “current verified” date.

`tests/smoke/chatgpt_current_dom_smoke.py` is the turn/composer compatibility sentinel. `tests/smoke/approval_recovery_smoke.py` includes the current generic-card, nested icon-only split button, portalled provider menu, and mutation-triggered automatic approval contract.
