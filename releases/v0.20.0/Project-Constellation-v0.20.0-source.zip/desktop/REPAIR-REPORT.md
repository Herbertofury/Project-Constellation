# 0.7.1 reliability baseline retained

The preceding repair report is supplied in the prior 0.7.1 release. The 0.7.2 change and verification record is README.md plus RELEASE-MANIFEST.json. All prior runtime, nonce, file conflict, process, outbox, and permission regressions remain in the executable test suite.
