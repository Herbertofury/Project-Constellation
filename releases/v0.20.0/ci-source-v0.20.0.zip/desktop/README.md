# Project Constellation 0.20.0

Project Constellation is a unified desktop + browser companion for authenticated ChatGPT work, project continuity, local computer tools, saved tasks, recovery, provider health, and durable project state. The normal ChatGPT experience uses the user's existing signed-in web session; it does not require a separate OpenAI API key.

## What is new in 0.20

- **Event-driven state core.** Home, side panel, Pulse, local Work routing, Scheduled recovery, and the desktop bridge now prefer real state/route events over fixed refresh loops.
- **Provider Health.** Provider adapters report capability-level health so a site change can identify the broken surface instead of failing mysteriously.
- **Incident Brain.** Verified recovery recipes are fingerprinted and reusable so recurring failures can take the known-good route first.
- **Brain DB v11.** Shared IndexedDB connection/migration ownership adds durable provider health, incident recipes, and migration receipts.
- **Update Center.** The desktop can check the stable GitHub release, verify SHA-256, stage a portable update, and preserve rollback.
- **Project Constellation desktop identity.** User-facing Commander branding has been unified under Project Constellation while legacy app IDs, state/config paths, CLI aliases, bridge protocol, and extension identity remain compatible with existing installations.
- **Windows-native release gate.** 0.20 cannot be considered release-ready without a passing Windows runtime receipt covering native computer-use, integrated Electron, and a freshly extracted portable build.
- **Full browser capability preserved.** The broad provider/host permission model remains intact by design.

## Start

For the portable build, extract the complete `Project-Constellation-v0.20.0-Windows-Portable.zip` into a new folder and run `Project Constellation.exe`. Keep the extracted folder together. Existing Project Constellation/Commander-era state and the persistent ChatGPT partition are intentionally reused for upgrade continuity.

The desktop keeps real ChatGPT at the center and adds local capabilities around it: Files, Terminal, Desktop/computer-use, saved Tasks, Activity, searchable Tools, provider/status diagnostics, and Update Center. Emergency Lock remains authoritative and permission/security/login prompts are never bypassed.

## Browser companion

The Project Constellation extension uses stable ID `geljambmkfjkhodgkpjhnmfojkpcamig` and the version-matched loopback bridge. It supports ChatGPT plus the existing broad provider host set. The bridge accepts only the trusted extension origin and preserves per-chat nonce/session-token authorization.

## Verification

Source-level acceptance for 0.20 includes:

- root regression + contract validation;
- 34/34 browser smoke workflows using real Chromium;
- desktop syntax/static/update-service checks;
- provider health, incident brain, DB v11, full-permission, message-router, and no-fixed-polling regressions;
- production extension packaging;
- a mandatory Windows-native runtime receipt before release publication.

See `RELEASE-MANIFEST.json` and `../docs/v0.20.0-release-notes.md` for the exact release contract. Authenticated account-specific ChatGPT behavior is intentionally left as user-runtime acceptance after delivery rather than simulated as proof.

## Development

Project Constellation 0.20.0 targets Node 24 in CI, Electron 44.4.4 stable, and electron-builder 26.16.1.

```text
npm run check
npm test
node tests/update-service.test.mjs
npm run build:win
```

The repository-level verification and packaging workflows live under `../.github/workflows/`. `windows-runtime.yml` is the authoritative native Windows release gate.

## Compatibility

Migration-sensitive identifiers are deliberately retained where changing them would strand user state or break the browser bridge. That includes the historical Electron app ID, Commander-era data/config locations, CLI aliases, and local bridge protocol names. These are compatibility internals, not separate products.
