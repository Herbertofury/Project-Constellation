import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const desktopPkg=JSON.parse(fs.readFileSync(path.join(root,'desktop','package.json'),'utf8'));
const version=pkg.version;
if(desktopPkg.version!==version)throw new Error(`Desktop ${desktopPkg.version} != root ${version}`);
const buildInfo=JSON.parse(fs.readFileSync(path.join(root,'build','build-info.json'),'utf8'));
if(buildInfo.version!==version)throw new Error('Extension build metadata version mismatch.');
const git=(args)=>{const r=spawnSync('git',args,{cwd:root,encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||r.stdout);return r.stdout.trim();};
const commit=git(['rev-parse','HEAD']);
const dirty=git(['status','--porcelain','--untracked-files=no']);
if(dirty)throw new Error('Unified release packaging requires a clean committed source tree.');
const releaseDir=path.join(root,'releases',`v${version}`);fs.rmSync(releaseDir,{recursive:true,force:true});fs.mkdirSync(releaseDir,{recursive:true});
const run=(cmd,args,cwd=root)=>{const r=spawnSync(cmd,args,{cwd,encoding:'utf8',stdio:'pipe'});if(r.status!==0)throw new Error(`${cmd}: ${r.stderr||r.stdout}`);};
const zipDir=(source,target)=>{fs.rmSync(target,{force:true});if(process.platform==='win32'){const q=v=>String(v).replaceAll("'","''");run('powershell.exe',['-NoProfile','-Command',`Compress-Archive -Path '${q(path.join(source,'*'))}' -DestinationPath '${q(target)}' -CompressionLevel Optimal -Force`]);}else run('zip',['-X','-q','-r',target,'.'],source);};
const extensionZip=path.join(releaseDir,`Project-Constellation-v${version}-Extension.zip`);zipDir(path.join(root,'build','unpacked'),extensionZip);
const sourceZip=path.join(releaseDir,`Project-Constellation-v${version}-source.zip`);run('git',['archive','--format=zip',`--output=${sourceZip}`,commit]);
const desktopDir=path.join(root,'desktop','dist-electron');
const desktopZip=fs.existsSync(desktopDir)?fs.readdirSync(desktopDir).map(name=>path.join(desktopDir,name)).find(file=>/\.zip$/i.test(file)&&/0\.20\.0|Project-Constellation/i.test(path.basename(file))):null;
if(!desktopZip)throw new Error('Windows portable ZIP missing. Run desktop npm run build:portable:win first.');
const portable=path.join(releaseDir,`Project-Constellation-v${version}-Windows-Portable.zip`);fs.copyFileSync(desktopZip,portable);
const installerSource=fs.readdirSync(desktopDir).map(name=>path.join(desktopDir,name)).find(file=>/\.exe$/i.test(file)&&!/uninstall/i.test(path.basename(file)));
let installer=null;if(installerSource){installer=path.join(releaseDir,`Project-Constellation-v${version}-Windows-Setup.exe`);fs.copyFileSync(installerSource,installer);}
const notesSource=path.join(root,'docs',`v${version}-release-notes.md`);if(!fs.existsSync(notesSource))throw new Error('Release notes missing.');const notes=path.join(releaseDir,path.basename(notesSource));fs.copyFileSync(notesSource,notes);
const sha256=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const windowsReceiptSource=path.join(desktopDir,'WINDOWS-RUNTIME-RECEIPT.json');
let windowsRuntime=null;
if(fs.existsSync(windowsReceiptSource)){
  windowsRuntime=JSON.parse(fs.readFileSync(windowsReceiptSource,'utf8').replace(/^\uFEFF/,''));
  fs.copyFileSync(windowsReceiptSource,path.join(releaseDir,'WINDOWS-RUNTIME-RECEIPT.json'));
}
const verificationSource=path.join(root,'release-verification.json');
let externalVerification={};
if(fs.existsSync(verificationSource))externalVerification=JSON.parse(fs.readFileSync(verificationSource,'utf8').replace(/^\uFEFF/,''));
const artifacts=[extensionZip,sourceZip,portable,...(installer?[installer]:[]),notes,...(windowsRuntime?[path.join(releaseDir,'WINDOWS-RUNTIME-RECEIPT.json')]:[])];
const sums=artifacts.map(file=>`${sha256(file)}  ${path.basename(file)}`).join('\n')+'\n';fs.writeFileSync(path.join(releaseDir,`SHA256SUMS-v${version}.txt`),sums);
const receipt={schema:'project-constellation-unified-release-v1',product:'Project Constellation',version,sourceCommit:commit,extensionId:'geljambmkfjkhodgkpjhnmfojkpcamig',extensionBuild:buildInfo,desktop:{electron:desktopPkg.devDependencies.electron,electronBuilder:desktopPkg.devDependencies['electron-builder']},artifacts:artifacts.map(file=>({name:path.basename(file),size:fs.statSync(file).size,sha256:sha256(file)})),verification:{sourceClean:true,portablePresent:true,checksumsGenerated:true,...externalVerification,...(windowsRuntime?{windowsRuntime}:{})},createdAt:new Date().toISOString()};
fs.writeFileSync(path.join(releaseDir,`RELEASE-RECEIPT-v${version}.json`),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
