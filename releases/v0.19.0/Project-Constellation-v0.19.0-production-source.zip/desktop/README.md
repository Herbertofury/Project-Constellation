# Constellation Commander 0.7.4 - saved work and indexed results

## New in this version
Activity now contains saved Tasks. Use **Run as saved task** beside the terminal command, the task builder in Activity, or ask the integrated chat to use `run_task`. A task is an explicit sequence of existing tools. Each step/result is persisted. `wait_for_exit:true` waits for a command and stops on nonzero exit. `{$result:"step_id/sha256"}` reuses a previous step result without a chat round trip. Use `get_task` to inspect results, `cancel_task` to stop at the next boundary, and `resume_task` only after inspecting failures. Completed steps are skipped. Uncertain interrupted actions require a local-user decision; they never automatically retry.

Search uses indexed result pages and persists results across restarts. Literal content search scans beyond the old 16 MB cutoff. Binary files, ignored paths and read errors are reported; `partial` is not presented as complete. Regex searches preserve full-string semantics. The index costs eight bytes per match. Recent activity reads the end of the audit log rather than the whole log. `read_process_output` accepts an independent `byte_offset` cursor, so task readers do not consume the terminal's output.

All 54 original tools remain, with five task tools added. Existing UI, ChatGPT profile, permissions and 0.7.3 request/delivery protections are preserved. No external watchdog, paid inference path, or permission escalation is introduced.

This is not an official ChatGPT app registration. Signed-in ChatGPT acceptance and native Windows execution have not been performed for this version. Real Electron Linux tests use an owned chat-service fixture. The portable reuses the prior Windows launcher, whose File Properties may show 0.7.0. Scripts for manually updating/rolling back are supplied, but have not been executed on Windows here.

## Reproduce
Run `npm test` and `npm run check`. Run `node tests/benchmark-pagination.mjs` for the equivalent-output pagination benchmark. Follow `tests/NATIVE-ACCEPTANCE.md` for the real-Electron source/package test. Benchmark ratios are not whole-application or network-speed claims.

---

## Existing workspace documentation

# Constellation Commander 0.7.3

An independent Windows workspace that keeps **real online ChatGPT** in the center and adds local computer controls around it. No separate OpenAI API key or API billing is required for the embedded ChatGPT path. Commander does not impersonate the official OpenAI app or remove account/platform limits.

## Start

Close Commander. Extract the complete 0.7.3 Windows Portable ZIP into a new folder and open `Constellation Commander.exe`. Keep the extracted folder together. Your existing Commander ChatGPT profile and local settings are reused; the update does not erase conversations or credentials. The Windows launcher is retained from the preceding build and Windows File Properties may still show 0.7.0; application code and the Commander UI are 0.7.3.

The small Manual Patch is an alternative for known 0.7.0 / 0.7.1 / 0.7.2 installations. It checks exact archive hashes, refuses running/unknown installations, backs up the old application archive, and supports rollback. Do not run an old installer after applying the upgrade.

## Daily use

- **Chat:** the actual ChatGPT website, account, conversations, model controls, attachments, and account-provided features. Commander does not recreate or substitute a fake chat screen. Availability still depends on your account and the embedded browser environment.
- **Computer access:** choose folders, GUI and shell permissions, and Auto / Always / Off. `Use computer for next message` explicitly arms the next prompt. `Stop` activates Emergency Lock and stops Commander-owned work.
- **Files:** browse and filter folders, go up, open in the system, edit text, and save with conflict detection. Opening another view does not discard the editor.
- **Terminal:** run real commands in a chosen folder, inspect incremental output and exit status, select existing sessions, send interactive input, copy output, and stop a process.
- **Desktop:** explicitly capture a fresh screen view and inspect/focus windows. Mouse, keyboard, clipboard and UI Automation remain available through local tools.
- **Activity:** recent operations and download status. Completed ChatGPT downloads can be revealed in their folder; executables are not automatically opened.
- **Tools:** searchable production tool catalog with schema-generated forms. Advanced JSON stays available.
- **Settings:** System / Light / Dark appearance, chat zoom, pin window, startup control, diagnostics and data-folder access.
- **Connect:** distinguish local runtime availability, ChatGPT page status, and the separate remote MCP connection.

The Inspector can collapse for more chat space. At narrow widths, Computer access opens as its own screen instead of overlapping the chat. Ctrl+Shift+P opens quick actions; Ctrl+Shift+E Files; Ctrl+Shift+T Terminal; Ctrl+Shift+H Chat; Ctrl+, Settings; Ctrl+S saves the editor; Ctrl+Enter runs the focused command. Native view switching keeps the same ChatGPT WebContentsView and persistent partition.

## Online computer access

Inside Commander, the existing nonce-authorized DOM/request adapter returns local tool results to the same chat and preserves unsent drafts. This adapter is **not an officially registered ChatGPT connector**. It must still be verified against your authenticated live session, and site changes can affect it.

For ordinary ChatGPT tabs or other devices, the Connect view pairs the computer with **your existing HTTPS Remote MCP relay**. Pairing opens in a restricted window; the same local execution policy governs remote jobs. Switching relay clears the previous relay credential. Disconnect cancels polling; repeated result delivery does not rerun the completed action. The relay source, Dockerfile and CLI are included. Deployment and the authorized ChatGPT plugin connection are separate steps; no public endpoint is bundled or silently created.

Official connection requirements and UI vary by account/workspace:
- https://developers.openai.com/plugins/deploy/connect-chatgpt
- https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt

No API key is requested to make normal ChatGPT work. A local health test is not proof of ChatGPT authentication. Commander does not bypass UAC, secure desktop, administrator controls, ChatGPT confirmations, or platform quotas. Arbitrary shell permission runs as your Windows user and is not constrained by filesystem roots as an OS sandbox would be.

## Verification

See `RELEASE-MANIFEST.json` and the test-evidence bundle. 50 Node regression tests and the existing integration suites passed for this source. In addition, 17 scenarios passed in actual Electron on Linux with real IPC and file/process handlers, using an owned ChatGPT-response fixture. The older 23-scenario substituted-IPC browser harness is retained for regression work but is not the runtime acceptance evidence for this release. Remote device tests exercise a real local relay; focused replay tests substitute HTTP responses to reproduce failed deliveries.

Native Windows execution, the PowerShell patch/rollback scripts, and your authenticated ChatGPT account were not executed in this Linux environment. Real Electron rendering and the actual application archive were exercised on Linux. The Windows-only gate reports SKIP. This is not a newly signed NSIS installer or a claim of complete official-app parity. Packaging is separately checked against source and the original Windows runtime is preserved.

## Development

Node 22.12+; existing pinned Electron 44.4.3 and electron-builder 26.16.1 are preserved for runtime compatibility.

```
npm run check
npm test
python tests/ui-regression.py
npm run build:win
```

The UI harness requires Python Playwright and BeautifulSoup4 and Chromium (`CHROMIUM_PATH` may override its executable path). No runtime NPM dependency was added for the visual redesign.

## 0.7.3 functional bridge repair

Use **Connections > Test chat access** with no unsent draft. This uses the actual embedded conversation, calls the real local ping tool, and waits for a correlated request acknowledgement. Adapter loaded, request accepted, action executing, result delivered, and result retained are different states.

The request hook only handles ChatGPT conversation endpoints and the latest user message. Historical matching prompts and unrelated requests are not rewritten. Arming waits for a handshake; delivery waits for generation to finish, preserves drafts, and retains completed results on rejected requests. Retrying sends the saved result without repeating the action. New user tasks rotate authorization; fragment/query changes do not redirect or strand saved results.

The release evidence includes 50 Node regressions and 17 scenarios exercised in **real Electron 44.4.4 on Linux**, both unpacked and through the delivered application archive. The ChatGPT response server is an owned fixture, not an authenticated account. The Windows portable retains its prior Electron runtime (44.4.3); native Windows, camera/microphone, PowerShell patch execution, and your authenticated account have not been tested in this environment. No full platform parity or registered remote-app status is claimed.
