@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Rollback-Patch.ps1"
pause
