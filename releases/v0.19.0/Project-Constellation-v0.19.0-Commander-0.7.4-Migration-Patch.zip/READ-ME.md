# Project Constellation 0.19.0 — Commander 0.7.4 migration patch

This patch upgrades the **exact verified Commander 0.7.4 desktop application code** into Project Constellation 0.19.0 without clearing its existing `.constellation-commander` profile, saved tasks, settings, or local Work state.

1. Close Commander.
2. Extract this ZIP.
3. Run `APPLY-PATCH.cmd` and select your existing `Constellation Commander.exe`.
4. The patch verifies the existing `resources/app.asar` hash before changing anything and creates a timestamped backup.

The in-place patch intentionally leaves the old executable filename in place so existing shortcuts keep working. The full 0.19.0 portable package uses `Project Constellation.exe` instead.

The patch does **not** install the retired standalone Commander browser extension. Use the Project Constellation extension included with the 0.19.0 release.

`ROLLBACK.cmd` restores only a verified backup created by this migration.
