param([string]$InstallDirectory)
$ErrorActionPreference='Stop'
$manifest=Get-Content (Join-Path $PSScriptRoot 'patch-manifest.json') -Raw | ConvertFrom-Json
if(-not $InstallDirectory){
 Add-Type -AssemblyName System.Windows.Forms
 $picker=New-Object System.Windows.Forms.OpenFileDialog
 $picker.Title='Select your existing Constellation Commander 0.7.4 executable (close it first)'
 $picker.Filter='Constellation Commander|Constellation Commander.exe'
 if($picker.ShowDialog() -ne 'OK'){return}
 $InstallDirectory=Split-Path $picker.FileName -Parent
}
$InstallDirectory=(Resolve-Path -LiteralPath $InstallDirectory).Path
$exe=Join-Path $InstallDirectory 'Constellation Commander.exe'
$target=Join-Path $InstallDirectory 'resources\app.asar'
if(-not (Test-Path -LiteralPath $exe) -or -not (Test-Path -LiteralPath $target)){throw 'This is not a supported Commander 0.7.4 installation folder.'}
$running=Get-CimInstance Win32_Process -Filter "Name='Constellation Commander.exe'" | Where-Object {($_.ExecutablePath -eq $exe -or -not $_.ExecutablePath)}
if($running){throw 'Close Commander normally, then run the patch again. No process was killed and no files were changed.'}
$source=Join-Path $PSScriptRoot 'resources\app.asar'
$newHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
if($newHash -ne $manifest.target_asar_sha256){throw 'Patch archive hash mismatch. No installation files were changed.'}
$oldHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
if($oldHash -eq $manifest.target_asar_sha256){Write-Host 'Project Constellation 0.19.0 application code is already installed.';return}
if(@($manifest.accepted_base_asar_sha256) -notcontains $oldHash){throw 'The installed app.asar is not the exact verified Commander 0.7.4 base. Use the complete Project Constellation 0.19.0 portable package instead; no files were changed.'}
$backup="$target.before-0.19.0.$([DateTime]::UtcNow.ToString('yyyyMMddHHmmss')).bak"
$temp="$target.patch-$([Guid]::NewGuid().ToString('N')).tmp"
try{
 Copy-Item -LiteralPath $source -Destination $temp
 if((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $newHash){throw 'Copied patch did not verify.'}
 [IO.File]::Replace($temp,$target,$backup)
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $newHash){throw "Installed hash mismatch. Restore backup: $backup"}
 Write-Host 'Project Constellation 0.19.0 application code installed.'
 Write-Host 'Your existing profile, saved tasks, settings, and shortcuts were preserved.'
 Write-Host 'The legacy Constellation Commander.exe filename is intentionally kept by this in-place patch so existing shortcuts do not break.'
 Write-Host "Backup: $backup"
} finally {if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
