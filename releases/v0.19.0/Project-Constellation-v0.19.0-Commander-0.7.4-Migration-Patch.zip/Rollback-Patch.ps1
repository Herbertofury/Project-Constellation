param([string]$InstallDirectory)
$ErrorActionPreference='Stop'
if(-not $InstallDirectory){
 Add-Type -AssemblyName System.Windows.Forms
 $picker=New-Object System.Windows.Forms.OpenFileDialog
 $picker.Title='Select the patched Constellation Commander.exe (close it first)'
 $picker.Filter='Constellation Commander|Constellation Commander.exe'
 if($picker.ShowDialog() -ne 'OK'){return}
 $InstallDirectory=Split-Path $picker.FileName -Parent
}
$InstallDirectory=(Resolve-Path -LiteralPath $InstallDirectory).Path
$exe=Join-Path $InstallDirectory 'Constellation Commander.exe'
if(Get-CimInstance Win32_Process -Filter "Name='Constellation Commander.exe'" | Where-Object {($_.ExecutablePath -eq $exe -or -not $_.ExecutablePath)}){throw 'Close the app before rollback.'}
$target=Join-Path $InstallDirectory 'resources\app.asar'
$manifest=Get-Content (Join-Path $PSScriptRoot 'patch-manifest.json') -Raw | ConvertFrom-Json
if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.target_asar_sha256){throw 'Installed application code changed after this patch; refusing rollback overwrite.'}
$backup=Get-ChildItem -LiteralPath (Split-Path $target -Parent) -Filter 'app.asar.before-0.19.0.*.bak' | Sort-Object Name -Descending | Select-Object -First 1
if(-not $backup){throw 'No matching 0.19.0 migration backup was found.'}
if(@($manifest.accepted_base_asar_sha256) -notcontains (Get-FileHash -LiteralPath $backup.FullName -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Backup hash does not match the verified Commander 0.7.4 base.'}
$temp="$target.rollback.tmp"
Copy-Item -LiteralPath $backup.FullName -Destination $temp
[IO.File]::Replace($temp,$target,"$target.rolled-back-0.19.0.bak")
Write-Host 'Restored the exact Commander 0.7.4 application archive. Profile/settings were not cleared.'
